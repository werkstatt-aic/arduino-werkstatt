"use strict";const WB_FONT=[0,0,0,0,0,8,8,8,0,8,10,10,0,0,0,10,31,10,31,10,14,25,14,19,14,25,18,4,9,19,12,18,12,18,13,8,8,0,0,0,4,8,8,8,4,8,4,4,4,8,0,10,4,10,0,0,4,14,4,0,0,0,0,4,8,0,0,14,0,0,0,0,0,8,0,1,2,4,8,16,12,18,18,18,12,4,12,4,4,14,28,2,12,16,30,30,2,4,18,12,6,10,18,31,2,31,16,30,1,30,2,4,14,17,14,31,2,4,8,16,14,17,14,17,14,14,17,14,4,8,0,8,0,8,0,0,4,0,4,8,2,4,8,4,2,0,14,0,14,0,8,4,2,4,8,14,17,6,0,4,14,17,21,19,12,12,18,30,18,18,28,18,28,18,28,14,16,16,16,14,28,18,18,18,28,30,16,28,16,30,30,16,28,16,16,14,16,19,17,14,18,18,30,18,18,28,8,8,8,28,31,2,2,18,12,18,20,24,20,18,16,16,16,16,30,17,27,21,17,17,17,25,21,19,17,12,18,18,18,12,28,18,28,16,16,12,18,18,12,6,28,18,28,18,17,14,16,12,2,28,31,4,4,4,4,18,18,18,18,12,17,17,17,10,4,17,17,21,27,17,18,18,12,18,18,17,10,4,4,4,30,4,8,16,30,14,8,8,8,14,16,8,4,2,1,14,2,2,2,14,4,10,0,0,0,0,0,0,0,31,8,4,0,0,0,0,14,18,18,15,16,16,28,18,28,0,14,16,16,14,2,2,14,18,14,12,18,28,16,14,6,8,28,8,8,14,18,14,2,12,16,16,28,18,18,8,0,8,8,8,2,0,2,2,12,16,20,24,20,18,8,8,8,8,6,0,27,21,17,17,0,28,18,18,18,0,12,18,18,12,0,28,18,28,16,0,14,18,14,2,0,14,16,16,16,0,6,8,4,24,8,8,14,8,7,0,18,18,18,15,0,17,17,10,4,0,17,17,21,27,0,18,12,12,18,0,17,10,4,24,0,30,4,8,30,6,4,12,4,6,8,8,8,8,8,24,8,12,8,24,0,0,12,3,0],WB_RUNTIME=String.raw`// ===== Werkstatt: Bordfunktionen micro:bit / Calliope mini =====
#if defined(_VARIANT_BBC_MICROBIT_) || defined(_VARIANT_CALLIOPE_MINI_)
#define WB_NRF51 1
#endif
static volatile uint8_t wbBild[5]; // je Zeile 5 Bit, Bit 4 = links
static const uint8_t wbSchrift[475] = {@SCHRIFT@}; // Schrift „pendolino3“ aus microbit-dal (MIT-Lizenz, Lancaster University/BBC)
#if WB_NRF51
#if defined(_VARIANT_CALLIOPE_MINI_)
static const uint8_t wbKarte[27][2] = {{0,0},{4,2},{2,4},{2,0},{0,2},{4,4},{4,0},{2,2},{0,4},{4,3},{1,0},{0,1},{3,3},{3,0},{1,1},{2,3},{3,4},{2,1},{1,3},{1,4},{3,1},{0,3},{9,9},{4,1},{1,2},{9,9},{3,2}};
#else
static const uint8_t wbKarte[27][2] = {{0,4},{0,3},{1,1},{1,4},{4,2},{0,1},{2,4},{3,2},{4,0},{3,4},{2,2},{3,0},{4,4},{1,2},{2,0},{4,3},{0,2},{1,0},{3,3},{4,1},{0,0},{2,3},{3,1},{9,9},{1,3},{2,1},{9,9}};
#endif
static const uint8_t WB_ZEILEN = 3;
#else
static const uint8_t wbZeilePin[5] = {21, 22, 23, 24, 25};
#if defined(_CALLIOPE_MINI_V3_)
static const uint8_t wbSpaltePin[5] = {4, 7, 18, 6, 10};
#else
static const uint8_t wbSpaltePin[5] = {4, 7, 3, 6, 10};
#endif
static const uint8_t WB_ZEILEN = 5;
#endif
static volatile uint8_t wbZeile = 0;
static bool wbAnzeigeAn = false;

// --- Servos (bis zu 8, nacheinander, alle 20 ms) ---
static int8_t wbServoPin[8] = {-1, -1, -1, -1, -1, -1, -1, -1};
static uint16_t wbServoUs[8];
static volatile int8_t wbServoAktiv = -1;
static volatile uint16_t wbServoStart = 0;
static bool wbTimerAn = false;

static void wbZeigeZeile() {
#if WB_NRF51
  uint32_t spalten = 0;
  for (uint8_t i = 0; i < 9; i++) {
    uint8_t x = wbKarte[i * 3 + wbZeile][0], y = wbKarte[i * 3 + wbZeile][1];
    if (x < 5 && (wbBild[y] & (0x10 >> x))) spalten |= 1u << i;
  }
  NRF_GPIO->OUTCLR = 0x7u << 13;                      // alle Zeilen aus
  NRF_GPIO->OUTSET = 0x1FFu << 4;                     // alle Spalten aus (HOCH)
  NRF_GPIO->OUTCLR = spalten << 4;                    // leuchtende Spalten NIEDRIG
  NRF_GPIO->OUTSET = 1u << (13 + wbZeile);            // Zeile an
#else
  static uint8_t vorher = 0;
  digitalWrite(wbZeilePin[vorher], LOW);
  for (uint8_t x = 0; x < 5; x++) digitalWrite(wbSpaltePin[x], (wbBild[wbZeile] & (0x10 >> x)) ? LOW : HIGH);
  digitalWrite(wbZeilePin[wbZeile], HIGH);
  vorher = wbZeile;
#endif
  wbZeile = (wbZeile + 1) % WB_ZEILEN;
}

extern "C" void TIMER2_IRQHandler(void) {
  if (NRF_TIMER2->EVENTS_COMPARE[0]) {               // LED-Anzeige: alle 1,5 ms die nächste Zeile
    NRF_TIMER2->EVENTS_COMPARE[0] = 0;
    NRF_TIMER2->CC[0] = (NRF_TIMER2->CC[0] + 1500) & 0xFFFF;
    if (wbAnzeigeAn) wbZeigeZeile();
  }
  if (NRF_TIMER2->EVENTS_COMPARE[1]) {               // Servos: Impuls des aktuellen Servos beenden, nächsten starten
    NRF_TIMER2->EVENTS_COMPARE[1] = 0;
    if (wbServoAktiv >= 0 && wbServoPin[wbServoAktiv] >= 0) digitalWrite(wbServoPin[wbServoAktiv], LOW);
    int8_t n = wbServoAktiv + 1;
    while (n < 8 && wbServoPin[n] < 0) n++;
    if (n < 8) {
      wbServoAktiv = n;
      digitalWrite(wbServoPin[n], HIGH);
      NRF_TIMER2->CC[1] = (NRF_TIMER2->CC[1] + wbServoUs[n]) & 0xFFFF;
    } else {                                           // Pause bis 20 ms nach dem Start der Runde
      wbServoAktiv = -1;
      wbServoStart = (wbServoStart + 20000) & 0xFFFF;
      NRF_TIMER2->CC[1] = wbServoStart;
    }
  }
}

static void wbTimerStart() {
  if (wbTimerAn) return;
  wbTimerAn = true;
  NRF_TIMER2->TASKS_STOP = 1;
  NRF_TIMER2->MODE = TIMER_MODE_MODE_Timer;
  NRF_TIMER2->BITMODE = TIMER_BITMODE_BITMODE_16Bit;
  NRF_TIMER2->PRESCALER = 4;                          // 1 MHz
  NRF_TIMER2->TASKS_CLEAR = 1;
  NRF_TIMER2->CC[0] = 1500;
  NRF_TIMER2->CC[1] = 20000;
  wbServoStart = 20000;
  NRF_TIMER2->INTENSET = TIMER_INTENSET_COMPARE0_Msk | TIMER_INTENSET_COMPARE1_Msk;
  NVIC_SetPriority(TIMER2_IRQn, 3);
  NVIC_ClearPendingIRQ(TIMER2_IRQn);
  NVIC_EnableIRQ(TIMER2_IRQn);
  NRF_TIMER2->TASKS_START = 1;
}

void anzeigeStart() {
  if (wbAnzeigeAn) return;
#if WB_NRF51
  NRF_GPIO->DIRSET = (0x7u << 13) | (0x1FFu << 4);
  NRF_GPIO->OUTSET = 0x1FFu << 4;
#else
  for (uint8_t i = 0; i < 5; i++) { pinMode(wbZeilePin[i], OUTPUT); digitalWrite(wbZeilePin[i], LOW); pinMode(wbSpaltePin[i], OUTPUT); digitalWrite(wbSpaltePin[i], HIGH); }
#endif
  wbAnzeigeAn = true;
  wbTimerStart();
}

void anzeigeLoeschen() { anzeigeStart(); for (uint8_t y = 0; y < 5; y++) wbBild[y] = 0; }
void anzeigeBild(uint32_t muster) { anzeigeStart(); for (uint8_t y = 0; y < 5; y++) wbBild[y] = (muster >> (20 - 5 * y)) & 0x1F; }
void anzeigePunkt(int x, int y, int an) {
  anzeigeStart();
  if (x < 0 || x > 4 || y < 0 || y > 4) return;
  if (an == 2) wbBild[y] ^= 0x10 >> x; else if (an) wbBild[y] |= 0x10 >> x; else wbBild[y] &= ~(0x10 >> x);
}
bool anzeigeLeuchtet(int x, int y) { return x >= 0 && x < 5 && y >= 0 && y < 5 && (wbBild[y] & (0x10 >> x)); }
static uint8_t wbZeichenZeile(char c, uint8_t y) { if (c < 32 || c > 126) c = '?'; return wbSchrift[(c - 32) * 5 + y]; }
void anzeigeText(String t, int pause) {
  anzeigeStart();
  if (t.length() == 1) { for (uint8_t y = 0; y < 5; y++) wbBild[y] = wbZeichenZeile(t[0], y); delay(pause * 5); return; }
  int breite = t.length() * 6 + 5;                    // je Zeichen 5 Spalten + 1 Abstand, dazu ein leerer Bildschirm
  for (int s = 0; s <= breite; s++) {
    for (uint8_t y = 0; y < 5; y++) {
      uint8_t z = 0;
      for (uint8_t x = 0; x < 5; x++) {
        int sp = s + x - 5, i = sp / 6, k = sp % 6;
        if (sp >= 0 && i < (int)t.length() && k < 5 && (wbZeichenZeile(t[i], y) & (0x10 >> k))) z |= 0x10 >> x;
      }
      wbBild[y] = z;
    }
    delay(pause);
  }
}
void anzeigeZahl(double z) {
  String s = (z == (long)z) ? String((long)z) : String(z, 2);
  if (s.indexOf('.') >= 0) { while (s.endsWith("0")) s.remove(s.length() - 1); if (s.endsWith(".")) s.remove(s.length() - 1); }
  anzeigeText(s, 150);
}

bool knopf(char k) {
  static bool bereit = false;
  if (!bereit) { pinMode(PIN_BUTTON_A, INPUT_PULLUP); pinMode(PIN_BUTTON_B, INPUT_PULLUP); bereit = true; }
  if (k == 'A') return digitalRead(PIN_BUTTON_A) == LOW;
  if (k == 'B') return digitalRead(PIN_BUTTON_B) == LOW;
  return digitalRead(PIN_BUTTON_A) == LOW && digitalRead(PIN_BUTTON_B) == LOW;
}

int temperatur() {
  NRF_TEMP->EVENTS_DATARDY = 0;
  NRF_TEMP->TASKS_START = 1;
  while (NRF_TEMP->EVENTS_DATARDY == 0) {}
  NRF_TEMP->EVENTS_DATARDY = 0;
  int t = (int)NRF_TEMP->TEMP;
  NRF_TEMP->TASKS_STOP = 1;
  return t / 4;
}

// --- Ton: tone()/noTone() gibt es im nRF-Paket nicht – hier mit TIMER0 ---
static volatile int8_t wbTonPin = -1;
static volatile uint8_t wbTonPegel = 0;
static volatile uint32_t wbTonEnde = 0;
extern "C" void TIMER0_IRQHandler(void) {
  NRF_TIMER0->EVENTS_COMPARE[0] = 0;
  if (wbTonPin < 0) return;
  if (wbTonEnde && (int32_t)(millis() - wbTonEnde) >= 0) { digitalWrite(wbTonPin, LOW); wbTonPin = -1; NRF_TIMER0->TASKS_STOP = 1; return; }
  wbTonPegel ^= 1;
  digitalWrite(wbTonPin, wbTonPegel);
}
void noTone(uint8_t pin) {
  if (wbTonPin == (int8_t)pin) { NRF_TIMER0->TASKS_STOP = 1; wbTonPin = -1; digitalWrite(pin, LOW); }
}
void tone(uint8_t pin, unsigned int frequenz, unsigned long dauer = 0) {
  if (frequenz < 20) { noTone(pin); return; }
  NRF_TIMER0->TASKS_STOP = 1;
  if (wbTonPin >= 0 && wbTonPin != (int8_t)pin) digitalWrite(wbTonPin, LOW);
  pinMode(pin, OUTPUT);
  NRF_TIMER0->MODE = TIMER_MODE_MODE_Timer;
  NRF_TIMER0->BITMODE = TIMER_BITMODE_BITMODE_16Bit;
  NRF_TIMER0->PRESCALER = 4;                          // 1 MHz
  NRF_TIMER0->CC[0] = 500000UL / frequenz;
  NRF_TIMER0->SHORTS = TIMER_SHORTS_COMPARE0_CLEAR_Msk;
  NRF_TIMER0->INTENSET = TIMER_INTENSET_COMPARE0_Msk;
  NVIC_SetPriority(TIMER0_IRQn, 2);
  NVIC_EnableIRQ(TIMER0_IRQn);
  wbTonEnde = dauer ? millis() + dauer : 0;
  wbTonPin = pin;
  NRF_TIMER0->TASKS_CLEAR = 1;
  NRF_TIMER0->TASKS_START = 1;
}

// --- eingebauter Lautsprecher ---
#if defined(_VARIANT_CALLIOPE_MINI_)
#define WB_LAUTSPRECHER 24                             // über den Motortreiber (IN1)
static void wbLautsprecherBereit() { pinMode(23, OUTPUT); digitalWrite(23, HIGH); pinMode(25, OUTPUT); digitalWrite(25, LOW); }
#elif defined(_VARIANT_BBC_MICROBIT_)
#define WB_LAUTSPRECHER 0                              // micro:bit V1 hat keinen Lautsprecher: Ton an P0 (Kopfhörer/Summer an P0 und GND)
static void wbLautsprecherBereit() {}
#else
#define WB_LAUTSPRECHER 27
static void wbLautsprecherBereit() {}
#endif
void lautsprecherTon(unsigned int frequenz, unsigned long dauer) { wbLautsprecherBereit(); tone(WB_LAUTSPRECHER, frequenz, dauer); if (dauer) delay(dauer); }
void lautsprecherAus() { noTone(WB_LAUTSPRECHER); }

// --- Servo (gleiche Befehle wie die Arduino-Bibliothek) ---
class Servo {
  int8_t nr = -1;
  int minUs = 544, maxUs = 2400;
public:
  void attach(int pin, int minimum = 544, int maximum = 2400) {
    minUs = minimum; maxUs = maximum;
    for (int8_t i = 0; i < 8 && nr < 0; i++) if (wbServoPin[i] < 0 || wbServoPin[i] == pin) nr = i;
    if (nr < 0) return;
    pinMode(pin, OUTPUT); digitalWrite(pin, LOW);
    wbServoUs[nr] = (minUs + maxUs) / 2; wbServoPin[nr] = pin;
    wbTimerStart();
  }
  void write(int winkel) { if (nr >= 0) wbServoUs[nr] = map(constrain(winkel, 0, 180), 0, 180, minUs, maxUs); }
  void writeMicroseconds(int us) { if (nr >= 0) wbServoUs[nr] = constrain(us, minUs, maxUs); }
};
// ===== Ende Bordfunktionen =====
`.replace("@SCHRIFT@",WB_FONT.join(",")),WB_RGB=()=>`#include <Adafruit_NeoPixel.h>
#if defined(_CALLIOPE_MINI_V3_)
Adafruit_NeoPixel wbRGB(3, 35, NEO_GRB + NEO_KHZ800);
#else
Adafruit_NeoPixel wbRGB(1, 26, NEO_GRB + NEO_KHZ800);
#endif
void rgbLed(int nr, int r, int g, int b) {
  static bool bereit = false;
  if (!bereit) { wbRGB.begin(); bereit = true; }
  for (int i = 0; i < (int)wbRGB.numPixels(); i++) if (nr <= 0 || nr == i + 1) wbRGB.setPixelColor(i, wbRGB.Color(r, g, b));
  wbRGB.show();
}`,WB_LAGE=String.raw`// ===== Werkstatt: Lage-Sensor (Beschleunigung) – micro:bit V1 (MMA8653, FXOS8700 oder LSM303), V2 und Calliope 3 (LSM303AGR), Calliope 1/2 (BMX055) =====
// Werte wie in MakeCode: 1 g ≈ 1024, x > 0 = nach rechts geneigt, y > 0 = Oberkante nach oben, z ≈ -1024 = liegt flach mit der Anzeige nach oben.
#include <Wire.h>
#if defined(_MICROBIT_V2_) || defined(_CALLIOPE_MINI_V3_)
#define WB_I2C Wire1                                   // interner I²C-Bus (Sensoren), getrennt von P19/P20
#else
#define WB_I2C Wire                                    // micro:bit V1 / Calliope 1/2: ein gemeinsamer Bus
#endif
static uint8_t wbLageChip = 0;                          // 1 LSM303, 2 MMA8653, 3 FXOS8700, 4 BMX055, 255 = keiner gefunden
static uint8_t wbLageAdr = 0;
static int wbLX = 0, wbLY = 0, wbLZ = -1024;
static uint32_t wbLageZeit = 0, wbSchuettelZeit = 0;
static bool wbSchuettelt = false;
static bool wbReg(uint8_t a, uint8_t r, uint8_t v) { WB_I2C.beginTransmission(a); WB_I2C.write(r); WB_I2C.write(v); return WB_I2C.endTransmission() == 0; }
static bool wbLies(uint8_t a, uint8_t r, uint8_t *d, uint8_t n) {
  WB_I2C.beginTransmission(a); WB_I2C.write(r);
  if (WB_I2C.endTransmission(false) != 0) return false;
  if (WB_I2C.requestFrom(a, n) != n) return false;
  for (uint8_t i = 0; i < n; i++) d[i] = WB_I2C.read();
  return true;
}
static void wbLageStart() {
  if (wbLageChip) return;
  WB_I2C.begin();
  delay(10);
  uint8_t id = 0;
  wbLageChip = 255;
  if (wbLies(0x18, 0x00, &id, 1) && id == 0xFA) {                   // BMX055 (Calliope mini 1/2)
    wbLageChip = 4; wbLageAdr = 0x18;
    wbReg(0x18, 0x14, 0xB6); delay(5);                             // Neustart
    wbReg(0x18, 0x0F, 0x03); wbReg(0x18, 0x10, 0x0C);              // ±2 g, 125 Hz
  } else if (wbLies(0x19, 0x0F, &id, 1) && id == 0x33) {            // LSM303AGR
    wbLageChip = 1; wbLageAdr = 0x19;
    wbReg(0x19, 0x20, 0x57); wbReg(0x19, 0x23, 0x80);              // 100 Hz, x/y/z an; ±2 g
  } else if (wbLies(0x1D, 0x0D, &id, 1) && id == 0x5A) {            // MMA8653 (frühe micro:bit V1)
    wbLageChip = 2; wbLageAdr = 0x1D;
    wbReg(0x1D, 0x2A, 0x00); wbReg(0x1D, 0x0E, 0x00); wbReg(0x1D, 0x2A, 0x01);
  } else if (wbLies(0x1E, 0x0D, &id, 1) && id == 0xC7) {            // FXOS8700 (micro:bit V1.5)
    wbLageChip = 3; wbLageAdr = 0x1E;
    wbReg(0x1E, 0x2A, 0x00); wbReg(0x1E, 0x5B, 0x00); wbReg(0x1E, 0x0E, 0x00); wbReg(0x1E, 0x2A, 0x01);
  }
}
static void wbLageLesen() {
  wbLageStart();
  if (wbLageChip == 255) return;
  if (wbLageZeit && millis() - wbLageZeit < 10) return;
  wbLageZeit = millis();
  uint8_t d[6];
  if (wbLageChip == 1) {
    if (!wbLies(wbLageAdr, 0x28 | 0x80, d, 6)) return;
    int16_t x = d[1] << 8 | d[0], y = d[3] << 8 | d[2], z = d[5] << 8 | d[4];
    wbLX = x / 16; wbLY = -y / 16; wbLZ = z / 16;
  } else if (wbLageChip == 2 || wbLageChip == 3) {
    if (!wbLies(wbLageAdr, 0x01, d, 6)) return;
    int16_t x = d[0] << 8 | d[1], y = d[2] << 8 | d[3], z = d[4] << 8 | d[5];
    wbLX = -x / 16; wbLY = -y / 16; wbLZ = z / 16;
  } else {
    if (!wbLies(0x18, 0x02, d, 6)) return;
    int16_t x = d[1] << 8 | d[0], y = d[3] << 8 | d[2], z = d[5] << 8 | d[4];
    wbLX = -y / 16; wbLY = -x / 16; wbLZ = -z / 16;
  }
  long b = (long)wbLX * wbLX + (long)wbLY * wbLY + (long)wbLZ * wbLZ;
  if (b > 1700L * 1700L) wbSchuettelZeit = millis();               // deutlich mehr als 1 g: geschüttelt
}
int beschleunigung(char achse) {
  wbLageLesen();
  if (achse == 'x') return wbLX;
  if (achse == 'y') return wbLY;
  if (achse == 'z') return wbLZ;
  return (int)sqrt((double)wbLX * wbLX + (double)wbLY * wbLY + (double)wbLZ * wbLZ);
}
int neigung(char art) {                                // 'r' = rollen (links/rechts), 'n' = nicken (vorn/hinten), in Grad
  wbLageLesen();
  double x = wbLX, y = wbLY, z = wbLZ;
  double rollen = atan2(x, -z);
  if (art == 'r') return (int)round(rollen * 180.0 / PI);
  return (int)round(atan2(y, x * sin(rollen) - z * cos(rollen)) * 180.0 / PI);
}
bool lage(int was) {                                  // wie die Gesten in MakeCode (Toleranz 200 mg)
  wbLageLesen();
  switch (was) {
    case 1: return wbLY > 800;                         // Oberkante nach oben
    case 2: return wbLY < -800;                        // Oberkante nach unten
    case 3: return wbLX < -800;                        // nach links geneigt
    case 4: return wbLX > 800;                         // nach rechts geneigt
    case 5: return wbLZ < -800;                        // liegt flach, Anzeige oben
    case 6: return wbLZ > 800;                         // liegt umgedreht, Anzeige unten
    case 7: return wbSchuettelZeit && millis() - wbSchuettelZeit < 1000;   // in der letzten Sekunde geschüttelt
    case 8: return beschleunigung('s') < 400;          // freier Fall
  }
  return false;
}
// ===== Ende Lage-Sensor =====
`,WB_MIKRO=String.raw`// ===== Werkstatt: Lautstärke über das eingebaute Mikrofon (0 bis 255, ungefähr wie MakeCode) =====
#if defined(_MICROBIT_V2_) || defined(_CALLIOPE_MINI_V3_)
#define WB_MIKRO 29
#define WB_MIKRO_AN 28                                 // RUN_MIC: Mikrofon einschalten
#elif defined(_VARIANT_CALLIOPE_MINI_)
#define WB_MIKRO 28
#endif
int lautstaerke() {
#ifdef WB_MIKRO
  static bool bereit = false;
  if (!bereit) {
#ifdef WB_MIKRO_AN
    pinMode(WB_MIKRO_AN, OUTPUT); digitalWrite(WB_MIKRO_AN, HIGH); delay(20);
#endif
    bereit = true;
  }
  int lo = 1023, hi = 0;
  uint32_t t = millis();
  while (millis() - t < 20) { int v = analogRead(WB_MIKRO); if (v < lo) lo = v; if (v > hi) hi = v; }
  return constrain((hi - lo) * 255 / 600, 0, 255);
#else
  return 0;                                            // micro:bit V1 hat kein Mikrofon
#endif
}
// ===== Ende Mikrofon =====
`,WB_MOTOR=String.raw`// ===== Werkstatt: Motoranschlüsse des Calliope mini (Leistung -100 … 100 %) =====
void bordMotor(int nr, int leistung) {
  leistung = constrain(leistung, -100, 100);
  int p = map(abs(leistung), 0, 100, 0, 255);
#if defined(_CALLIOPE_MINI_V3_)
  pinMode(36, OUTPUT); digitalWrite(36, HIGH);         // Motortreiber: Richtung/Tempo-Betrieb
  if (nr != 2) { pinMode(37, OUTPUT); digitalWrite(37, leistung < 0); analogWrite(38, p); }   // Motor A (M0)
  if (nr != 1) { pinMode(39, OUTPUT); digitalWrite(39, leistung < 0); analogWrite(40, p); }   // Motor B (M1)
#elif defined(_VARIANT_CALLIOPE_MINI_)
  pinMode(23, OUTPUT); digitalWrite(23, leistung != 0); // Motortreiber wecken (ein Motor zwischen den Anschlüssen)
  if (leistung >= 0) { analogWrite(25, 0); analogWrite(24, p); } else { analogWrite(24, 0); analogWrite(25, p); }
#endif
}
// ===== Ende Motor =====
`,WB_LAGEN=[["geschüttelt","7"],["mit der Oberkante nach oben","1"],["mit der Oberkante nach unten","2"],["nach links geneigt","3"],["nach rechts geneigt","4"],["flach mit Anzeige oben","5"],["flach mit Anzeige unten","6"],["im freien Fall","8"]],WB_SYMBOLE=[["Herz","01010 11111 11111 01110 00100"],["kleines Herz","00000 01010 01110 00100 00000"],["fröhlich","00000 01010 00000 10001 01110"],["traurig","00000 01010 00000 01110 10001"],["Haken","00000 00001 00010 10100 01000"],["Kreuz","10001 01010 00100 01010 10001"],["Pfeil hoch","00100 01110 10101 00100 00100"],["Pfeil runter","00100 00100 10101 01110 00100"],["Pfeil links","00100 01000 11111 01000 00100"],["Pfeil rechts","00100 00010 11111 00010 00100"],["Quadrat","11111 10001 10001 10001 11111"],["Punkt","00000 00000 00100 00000 00000"]],wbMuster=e=>parseInt(e.replace(/\s+/g,""),2);function FieldLed(e){FieldLed.superClass_.constructor.call(this,e===!0||e==="TRUE"?"TRUE":"FALSE")}Blockly.utils.object.inherits(FieldLed,Blockly.Field),FieldLed.fromJson=e=>new FieldLed(e.checked?"TRUE":"FALSE"),FieldLed.prototype.SERIALIZABLE=!0,FieldLed.prototype.EDITABLE=!0,FieldLed.prototype.CURSOR="pointer",FieldLed.prototype.doClassValidation_=function(e){return e===!0||e==="TRUE"?"TRUE":e===!1||e==="FALSE"?"FALSE":null},FieldLed.prototype.getText_=function(){return this.getValue()==="TRUE"?"■":"□"},FieldLed.prototype.initView=function(){this.ledRect_=Blockly.utils.dom.createSvgElement("rect",{x:.5,y:.5,width:15,height:15,rx:2.5,ry:2.5},this.fieldGroup_)},FieldLed.prototype.render_=function(){const e=this.getValue()==="TRUE";this.ledRect_&&Object.assign(this.ledRect_.style,{fill:e?"#ff2d20":"#ffffff",fillOpacity:"1",stroke:e?"#a3150d":"#9aa3a8",strokeWidth:"1px"}),this.size_.width=16,this.size_.height=16},FieldLed.prototype.updateSize_=function(){},FieldLed.prototype.showEditor_=function(){this.setValue(this.getValue()==="TRUE"?"FALSE":"TRUE")},Blockly.fieldRegistry.register("field_led",FieldLed);function wbSymbolBild(e){const n=e.replace(/\s+/g,"");let t="";for(let i=0;i<25;i++)t+=`<rect x="${1+i%5*5}" y="${1+Math.floor(i/5)*5}" width="4" height="4" rx="1" fill="${n[i]==="1"?"#ff3b2f":"#2b2f34"}"/>`;return"data:image/svg+xml;charset=utf-8,"+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26"><rect width="26" height="26" rx="3" fill="#15181b"/>${t}</svg>`)}SCH.bord="#0b7f8c",BLOCK_GROUPS.bord=[["wb_bild","wb_symbol","wb_text","wb_zahl","wb_loeschen","wb_punkt","wb_leuchtet"],["wb_knopf"],["wb_temp","wb_lage","wb_beschl","wb_neigung","wb_laut"],["wb_ton","wb_ton_freq","wb_ton_aus"],["wb_rgb","wb_rgb_aus"],["wb_motor","wb_motor_aus"]],BLOCK_GROUPS.bord.forEach(e=>e.forEach(n=>{BLOCK_COLOUR[n]=SCH.bord}));function defineBordBlocks(){const e={previousStatement:null,nextStatement:null,colour:SCH.bord},n=[];for(let t=0;t<5;t++)n.push({["message"+(t+1)]:"%1 %2 %3 %4 %5",["args"+(t+1)]:[0,1,2,3,4].map(i=>({type:"field_led",name:`L${i}${t}`,checked:!1}))});Blockly.defineBlocksWithJsonArray([Object.assign({type:"wb_bild",message0:"zeige Bild"},...n,e,{tooltip:"Zeigt ein eigenes Bild auf der LED-Anzeige (5 × 5). Feld anklicken: rot = LED leuchtet."}),Object.assign({type:"wb_symbol",message0:"zeige Symbol %1",args0:[{type:"field_dropdown",name:"S",options:WB_SYMBOLE.map(([t,i])=>[{src:wbSymbolBild(i),width:32,height:32,alt:t},i])}],tooltip:"Zeigt ein fertiges Bild auf der LED-Anzeige."},e),Object.assign({type:"wb_text",message0:"zeige Text %1",args0:[{type:"input_value",name:"V"}],inputsInline:!0,tooltip:"Lässt den Text über die LED-Anzeige laufen. Das Programm wartet, bis er durch ist."},e),Object.assign({type:"wb_zahl",message0:"zeige Zahl %1",args0:[{type:"input_value",name:"V",check:"Number"}],inputsInline:!0,tooltip:"Zeigt eine Zahl auf der LED-Anzeige (mehrstellige Zahlen laufen durch)."},e),Object.assign({type:"wb_loeschen",message0:"Anzeige löschen",tooltip:"Schaltet alle LEDs der Anzeige aus."},e),Object.assign({type:"wb_punkt",message0:"LED x %1 y %2 %3",args0:[{type:"input_value",name:"X",check:"Number"},{type:"input_value",name:"Y",check:"Number"},{type:"field_dropdown",name:"M",options:[["einschalten","1"],["ausschalten","0"],["umschalten","2"]]}],inputsInline:!0,tooltip:"Eine einzelne LED der Anzeige. x = Spalte von links (0 bis 4), y = Zeile von oben (0 bis 4)."},e),{type:"wb_leuchtet",message0:"LED x %1 y %2 leuchtet?",args0:[{type:"input_value",name:"X",check:"Number"},{type:"input_value",name:"Y",check:"Number"}],inputsInline:!0,output:"Boolean",colour:SCH.bord,tooltip:"Wahr, wenn diese LED der Anzeige gerade leuchtet."},{type:"wb_knopf",message0:"Knopf %1 gedrückt?",args0:[{type:"field_dropdown",name:"K",options:[["A","A"],["B","B"],["A+B","AB"]]}],output:"Boolean",colour:SCH.bord,tooltip:"Wahr, solange der Knopf gedrückt ist. „A+B“: beide gleichzeitig."},{type:"wb_temp",message0:"Temperatur (°C)",output:"Number",colour:SCH.bord,tooltip:"Temperatur des eingebauten Sensors im Prozessor in ganzen Grad. Sie liegt meist etwas über der Raumtemperatur."},{type:"wb_lage",message0:"Board %1 ?",args0:[{type:"field_dropdown",name:"L",options:WB_LAGEN}],output:"Boolean",colour:SCH.bord,tooltip:"Fragt den Lage-Sensor: Wie wird das Board gerade gehalten? „geschüttelt“ bleibt nach dem Schütteln eine Sekunde lang wahr."},{type:"wb_beschl",message0:"Beschleunigung %1 (mg)",args0:[{type:"field_dropdown",name:"A",options:[["x (links/rechts)","x"],["y (vorn/hinten)","y"],["z (oben/unten)","z"],["Stärke","s"]]}],output:"Number",colour:SCH.bord,tooltip:"Beschleunigung in Milli-g: 1 g (Erdanziehung) ≈ 1024. Liegt das Board flach, ist z ≈ -1024."},{type:"wb_neigung",message0:"Neigung %1 (°)",args0:[{type:"field_dropdown",name:"A",options:[["links/rechts","r"],["vorn/hinten","n"]]}],output:"Number",colour:SCH.bord,tooltip:"Neigungswinkel in Grad: links/rechts – nach rechts positiv; vorn/hinten – Oberkante hoch positiv."},{type:"wb_laut",message0:"Lautstärke",output:"Number",colour:SCH.bord,tooltip:"Lautstärke am eingebauten Mikrofon, 0 (still) bis 255 (sehr laut). Nicht beim micro:bit V1."},Object.assign({type:"wb_motor",message0:"Motor %1 Leistung %2 %",args0:[{type:"field_dropdown",name:"M",options:()=>NRF_CHIP==="cal3"?[["A","1"],["B","2"],["A und B","0"]]:[["","0"]]},{type:"input_value",name:"P",check:"Number"}],inputsInline:!0,tooltip:"Eingebauter Motoranschluss des Calliope mini: -100 (rückwärts) bis 100 % (vorwärts), 0 = aus. Beim mini 1/2 ein Motor, beim mini 3 zwei (A und B)."},e),Object.assign({type:"wb_motor_aus",message0:"Motoren aus",tooltip:"Hält die Motoren am Calliope an."},e),Object.assign({type:"wb_ton",message0:"spiele Ton %1 %2 %3 für %4 Sekunden",args0:[{type:"field_dropdown",name:"NOTE",options:NOTES},{type:"field_dropdown",name:"ACC",options:ACCS},{type:"field_dropdown",name:"OCT",options:OCTS},{type:"input_value",name:"DUR",check:"Number"}],inputsInline:!0,tooltip:"Spielt einen Ton auf dem eingebauten Lautsprecher (micro:bit V1: an P0). Das Programm wartet, bis der Ton zu Ende ist."},e),Object.assign({type:"wb_ton_freq",message0:"spiele Frequenz %1 Hz für %2 Sekunden",args0:[{type:"input_value",name:"FREQ",check:"Number"},{type:"input_value",name:"DUR",check:"Number"}],inputsInline:!0,tooltip:"Spielt eine Frequenz auf dem eingebauten Lautsprecher. Dauer 0: Ton bleibt an, bis „Lautsprecher aus“."},e),Object.assign({type:"wb_ton_aus",message0:"Lautsprecher aus",tooltip:"Beendet den Ton."},e),Object.assign({type:"wb_rgb",message0:"RGB-LED %1 Farbe %2",args0:[{type:"field_dropdown",name:"N",options:()=>NRF_CHIP==="cal3"?[["alle","0"],["1","1"],["2","2"],["3","3"]]:[["","0"]]},{type:"field_colour",name:"C",colour:"#ff0000"}],tooltip:"Die eingebaute RGB-LED des Calliope mini (beim mini 3: drei LEDs) in der gewählten Farbe."},e),Object.assign({type:"wb_rgb_aus",message0:"RGB-LED aus",tooltip:"Schaltet die eingebaute RGB-LED aus."},e)])}function bordToolbox(){return isNrf()?`<category name="${isCalliope()?"Calliope":"micro:bit"}" colour="${SCH.bord}">
    <label text="LED-Anzeige"></label>
    <block type="wb_symbol"></block>
    <block type="wb_bild"><field name="L10">TRUE</field><field name="L30">TRUE</field><field name="L01">TRUE</field><field name="L11">TRUE</field><field name="L21">TRUE</field><field name="L31">TRUE</field><field name="L41">TRUE</field><field name="L02">TRUE</field><field name="L12">TRUE</field><field name="L22">TRUE</field><field name="L32">TRUE</field><field name="L42">TRUE</field><field name="L13">TRUE</field><field name="L23">TRUE</field><field name="L33">TRUE</field><field name="L24">TRUE</field></block>
    <block type="wb_text"><value name="V">${txt("Hallo")}</value></block>
    <block type="wb_zahl"><value name="V">${num(42)}</value></block>
    <block type="wb_loeschen"></block>
    <block type="wb_punkt"><value name="X">${num(2)}</value><value name="Y">${num(2)}</value></block>
    <block type="wb_leuchtet"><value name="X">${num(2)}</value><value name="Y">${num(2)}</value></block>
    <label text="Knöpfe"></label>
    <block type="wb_knopf"></block>
    <label text="Sensoren"></label>
    <block type="wb_temp"></block>
    <block type="wb_lage"></block>
    <block type="wb_neigung"></block>
    <block type="wb_beschl"></block>
    ${NRF_CHIP==="mb1"?"":'<block type="wb_laut"></block>'}
    <label text="${NRF_CHIP==="mb1"?"Ton (an P0)":"Lautsprecher"}"></label>
    <block type="wb_ton"><field name="NOTE">9</field><field name="OCT">4</field><value name="DUR">${num(.5)}</value></block>
    <block type="wb_ton_freq"><value name="FREQ">${num(440)}</value><value name="DUR">${num(.5)}</value></block>
    <block type="wb_ton_aus"></block>
    ${isCalliope()?`<label text="RGB-LED"></label>
    <block type="wb_rgb"></block>
    <block type="wb_rgb_aus"></block>
    <label text="Motoren"></label>
    <block type="wb_motor"><value name="P">${num(50)}</value></block>
    <block type="wb_motor_aus"></block>`:""}
  </category>`:""}const wbBildMuster=e=>{let n=0;for(let t=0;t<5;t++)for(let i=0;i<5;i++)n=n*2+(e.getFieldValue(`L${i}${t}`)==="TRUE"?1:0);return n},wbFarbe=e=>[parseInt(e.slice(1,3),16),parseInt(e.slice(3,5),16),parseInt(e.slice(5,7),16)],wbSek=e=>`(${e}) * 1000`;function bordCpp(e){const n=(i,l,a)=>e.valueToCode(i,l,e.ORDER_NONE)||a||"0",t=i=>"0b"+i.toString(2).padStart(25,"0");e.wb_bild=i=>`anzeigeBild(${t(wbBildMuster(i))});
`,e.wb_symbol=i=>{const l=WB_SYMBOLE.find(a=>a[1]===i.getFieldValue("S"));return`anzeigeBild(${t(wbMuster(i.getFieldValue("S")))}); // ${l?l[0]:"Symbol"}
`},e.wb_text=i=>`anzeigeText(String(${n(i,"V",'""')}), 150);
`,e.wb_zahl=i=>`anzeigeZahl(${n(i,"V")});
`,e.wb_loeschen=()=>`anzeigeLoeschen();
`,e.wb_punkt=i=>`anzeigePunkt(${n(i,"X")}, ${n(i,"Y")}, ${i.getFieldValue("M")});
`,e.wb_leuchtet=i=>[`anzeigeLeuchtet(${n(i,"X")}, ${n(i,"Y")})`,e.ORDER_ATOMIC],e.wb_knopf=i=>[`knopf('${i.getFieldValue("K")==="AB"?"+":i.getFieldValue("K")}')`,e.ORDER_ATOMIC],e.wb_temp=()=>["temperatur()",e.ORDER_ATOMIC],e.wb_ton=i=>`lautsprecherTon(${noteFreq(i.getFieldValue("NOTE"),i.getFieldValue("ACC"),i.getFieldValue("OCT"))}, ${wbSek(n(i,"DUR"))});
`,e.wb_ton_freq=i=>`lautsprecherTon(${n(i,"FREQ")}, ${wbSek(n(i,"DUR"))});
`,e.wb_ton_aus=()=>`lautsprecherAus();
`,e.wb_rgb=i=>{e.helpers_.wbRgb=WB_RGB();const[l,a,r]=wbFarbe(i.getFieldValue("C"));return`rgbLed(${i.getFieldValue("N")||0}, ${l}, ${a}, ${r});
`},e.wb_rgb_aus=()=>(e.helpers_.wbRgb=WB_RGB(),`rgbLed(0, 0, 0, 0);
`),e.wb_lage=i=>(e.helpers_.wbLage=WB_LAGE,[`lage(${i.getFieldValue("L")})`,e.ORDER_ATOMIC]),e.wb_beschl=i=>(e.helpers_.wbLage=WB_LAGE,[`beschleunigung('${i.getFieldValue("A")}')`,e.ORDER_ATOMIC]),e.wb_neigung=i=>(e.helpers_.wbLage=WB_LAGE,[`neigung('${i.getFieldValue("A")}')`,e.ORDER_ATOMIC]),e.wb_laut=()=>(e.helpers_.wbMikro=WB_MIKRO,["lautstaerke()",e.ORDER_ATOMIC]),e.wb_motor=i=>(e.helpers_.wbMotor=WB_MOTOR,`bordMotor(${i.getFieldValue("M")||0}, ${n(i,"P")});
`),e.wb_motor_aus=()=>(e.helpers_.wbMotor=WB_MOTOR,`bordMotor(0, 0);
`),wbNurMitBoard(e,()=>["0",e.ORDER_ATOMIC],`// (Block nur mit micro:bit oder Calliope mini)
`,`// (gibt es nur beim Calliope mini)
`)}function wbNurMitBoard(e,n,t,i){for(const l of Object.keys(e).filter(a=>/^wb_/.test(a))){const a=e[l];e[l]=r=>isNrf()?/^wb_(rgb|motor)/.test(l)&&!isCalliope()?i:a(r):r.outputConnection?n():t}}function bordSim(e){const n=(t,i,l)=>e.valueToCode(t,i,e.ORDER_NONE)||l||"0";e.wb_bild=t=>`await api.anzeigeBild(${wbBildMuster(t)});
`,e.wb_symbol=t=>`await api.anzeigeBild(${wbMuster(t.getFieldValue("S"))});
`,e.wb_text=t=>`await api.anzeigeText(api.fmt(${n(t,"V","''")}));
`,e.wb_zahl=t=>`await api.anzeigeZahl(${n(t,"V")});
`,e.wb_loeschen=()=>`await api.anzeigeBild(0);
`,e.wb_punkt=t=>`await api.anzeigePunkt(${n(t,"X")}, ${n(t,"Y")}, ${t.getFieldValue("M")});
`,e.wb_leuchtet=t=>[`api.anzeigeLeuchtet(${n(t,"X")}, ${n(t,"Y")})`,e.ORDER_FUNCTION_CALL],e.wb_knopf=t=>[`(await api.knopf('${t.getFieldValue("K")}'))`,e.ORDER_ATOMIC],e.wb_temp=()=>["(await api.temperatur())",e.ORDER_ATOMIC],e.wb_ton=t=>`await api.lautsprecher(${noteFreq(t.getFieldValue("NOTE"),t.getFieldValue("ACC"),t.getFieldValue("OCT"))}, ${n(t,"DUR")});
`,e.wb_ton_freq=t=>`await api.lautsprecher(${n(t,"FREQ")}, ${n(t,"DUR")});
`,e.wb_ton_aus=()=>`await api.lautsprecher(0, 0);
`,e.wb_rgb=t=>`await api.rgb(${t.getFieldValue("N")||0}, ${JSON.stringify(wbFarbe(t.getFieldValue("C")))});
`,e.wb_rgb_aus=()=>`await api.rgb(0, [0, 0, 0]);
`,e.wb_lage=t=>[`(await api.lage(${t.getFieldValue("L")}))`,e.ORDER_ATOMIC],e.wb_beschl=t=>[`(await api.beschleunigung('${t.getFieldValue("A")}'))`,e.ORDER_ATOMIC],e.wb_neigung=t=>[`(await api.neigung('${t.getFieldValue("A")}'))`,e.ORDER_ATOMIC],e.wb_laut=()=>["(await api.lautstaerke())",e.ORDER_ATOMIC],e.wb_motor=t=>`await api.bordMotor(${t.getFieldValue("M")||0}, ${n(t,"P")});
`,e.wb_motor_aus=()=>`await api.bordMotor(0, 0);
`,wbNurMitBoard(e,()=>["false",e.ORDER_ATOMIC],"","")}function wbTextZeilen(e,n){const t=e.charCodeAt(0);return WB_FONT[(t<32||t>126?31:t-32)*5+n]}const wbN=e=>`<block type="math_number"><field name="NUM">${e}</field></block>`,wbMain=(e,n)=>`<xml xmlns="https://developers.google.com/blockly/xml"><block type="ard_main" x="30" y="30"><statement name="SETUP">${e}</statement><statement name="LOOP">${n}</statement></block></xml>`,wbSym=(e,n)=>`<block type="wb_symbol"><field name="S">${WB_SYMBOLE.find(t=>t[0]===e)[1]}</field>${n?`<next>${n}</next>`:""}</block>`,wbWait=(e,n)=>`<block type="ard_wait"><field name="UNIT">S</field><value name="N">${wbN(e)}</value>${n?`<next>${n}</next>`:""}</block>`,WB_BEISPIELE=[{id:"wb-herz",title:"Herzschlag",desc:"Die LED-Anzeige zeigt abwechselnd ein großes und ein kleines Herz.",blocks:wbMain("",wbSym("Herz",wbWait(.5,wbSym("kleines Herz",wbWait(.5)))))},{id:"wb-wuerfel",title:"Würfel",desc:"Knopf A drücken: Die Anzeige zeigt eine Zufallszahl von 1 bis 6 und es piept kurz.",blocks:wbMain(wbSym("Punkt"),`<block type="controls_if"><value name="IF0"><block type="wb_knopf"><field name="K">A</field></block></value><statement name="DO0"><block type="wb_zahl"><value name="V"><block type="math_random_int"><value name="FROM">${wbN(1)}</value><value name="TO">${wbN(6)}</value></block></value><next><block type="wb_ton"><field name="NOTE">0</field><field name="ACC">0</field><field name="OCT">5</field><value name="DUR">${wbN(.1)}</value></block></next></block></statement></block>`)},{id:"wb-thermo",title:"Thermometer",desc:"Zeigt immer wieder die Temperatur des eingebauten Sensors. Knopf B zeigt dazwischen ein Smiley.",blocks:wbMain("",`<block type="wb_zahl"><value name="V"><block type="wb_temp"></block></value><next><block type="controls_if"><value name="IF0"><block type="wb_knopf"><field name="K">B</field></block></value><statement name="DO0">${wbSym("fröhlich",wbWait(1))}</statement><next>${wbWait(1)}</next></block></next></block>`)}];function wbBeispiel(e){const n=isNrf()?NRF_CHIP:"cal1";return Object.assign({},e,{board:"nrf",chip:n,ext:[],circuit:{components:[{id:"c1",type:NRF_KEY[n],x:0,y:0,rot:0,props:{temp:21}}],wires:[]}})}
