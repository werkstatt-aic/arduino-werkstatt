"use strict";var W=Object.freeze,J=Object.defineProperty;var x=(t,i)=>W(J(t,"raw",{value:W(i||t.slice())}));var y;function btReceiverCode(t){return`// ===== Bluetooth-Übertragung (von der Arduino-Werkstatt eingefügt) =====
// Damit kann ein neues Programm per Bluetooth auf diesen ESP32 übertragen werden.
#define WS_DIENST   "${BT_UUID.svc}"
#define WS_STEUERN  "${BT_UUID.ctrl}"
#define WS_DATEN    "${BT_UUID.data}"
static volatile bool wsNeustart = false;

class WsSteuernCb : public NimBLECharacteristicCallbacks {
  void onWrite(NimBLECharacteristic *c, NimBLEConnInfo &info) override {
    String befehl(c->getValue().c_str());
    if (befehl.startsWith("START ")) {
      // "START <Groesse> <MD5-Pruefsumme>"
      int leer = befehl.indexOf(' ', 6);
      size_t groesse = befehl.substring(6, leer > 0 ? leer : befehl.length()).toInt();
      if (Update.isRunning()) Update.abort();
      bool ok = Update.begin(groesse);
      if (ok && leer > 0) Update.setMD5(befehl.substring(leer + 1).c_str());
      c->setValue(ok ? "OK" : "FEHLER Speicher");
    } else if (befehl == "ENDE") {
      // Nur übernehmen, wenn alles angekommen ist und die Prüfsumme stimmt
      if (Update.end(false)) { c->setValue("FERTIG"); wsNeustart = true; }
      else c->setValue("FEHLER Pruefung");
    } else if (befehl == "ABBRUCH") {
      if (Update.isRunning()) Update.abort();
      c->setValue("ABGEBROCHEN");
    }
  }
};

class WsDatenCb : public NimBLECharacteristicCallbacks {
  void onWrite(NimBLECharacteristic *c, NimBLEConnInfo &info) override {
    NimBLEAttValue v = c->getValue();
    if (v.size() > 0 && Update.isRunning()) Update.write((uint8_t *)v.data(), v.size());
  }
};

class WsServerCb : public NimBLEServerCallbacks {
  void onConnect(NimBLEServer *s, NimBLEConnInfo &info) override {
    // Kürzeres Funkintervall (7,5–15 ms) und größere Datenpakete: schnellere Übertragung
    s->updateConnParams(info.getConnHandle(), 6, 12, 0, 400);
    s->setDataLen(info.getConnHandle(), 251);
  }
};

void werkstattBluetooth()
{
  NimBLEDevice::init("${t}");
  NimBLEDevice::setMTU(517);
  NimBLEServer *server = NimBLEDevice::createServer();
  server->advertiseOnDisconnect(true);
  server->setCallbacks(new WsServerCb());
  NimBLEService *dienst = server->createService(WS_DIENST);
  NimBLECharacteristic *steuern = dienst->createCharacteristic(WS_STEUERN, NIMBLE_PROPERTY::READ | NIMBLE_PROPERTY::WRITE);
  steuern->setCallbacks(new WsSteuernCb());
  steuern->setValue("BEREIT");
  NimBLECharacteristic *daten = dienst->createCharacteristic(WS_DATEN, NIMBLE_PROPERTY::WRITE | NIMBLE_PROPERTY::WRITE_NR);
  daten->setCallbacks(new WsDatenCb());
  dienst->start();
  NimBLEAdvertising *werbung = NimBLEDevice::getAdvertising();
  werbung->addServiceUUID(WS_DIENST);
  werbung->enableScanResponse(true);
  werbung->setName("${t}");
  werbung->start();
  // Nach erfolgreicher Übertragung neu starten (unabhängig vom eigenen Programm)
  xTaskCreate([](void *) {
    for (;;) {
      if (wsNeustart) { vTaskDelay(800 / portTICK_PERIOD_MS); ESP.restart(); }
      vTaskDelay(100 / portTICK_PERIOD_MS);
    }
  }, "werkstatt", 2048, nullptr, 1, nullptr);
}
// ===== Ende Bluetooth-Übertragung =====`}const FLOAT_BLOCKS=new Set(["ard_dht","com_usb_num","com_radio_num","com_bt_num","ard_tmp36","ard_ultrasonic","read_voltmeter_differential","read_voltmeter_channel","calculate_pmfc_power","read_ina219_value"]),STRING_BLOCKS=new Set(["text","ard_join","kp_key","com_usb_text","com_wifi_ip","com_radio_text","com_bt_text"]);function valueType(t){if(!t)return"int";if(STRING_BLOCKS.has(t.type))return"String";if(FLOAT_BLOCKS.has(t.type))return"float";if(t.type==="math_number")return Number.isInteger(Number(t.getFieldValue("NUM")))?"int":"float";if(t.type==="math_arithmetic"){if(t.getFieldValue("OP")==="DIVIDE"||t.getFieldValue("OP")==="POWER")return"float";const i=widest([valueType(t.getInputTargetBlock("A")),valueType(t.getInputTargetBlock("B"))]);return i==="String"?"float":i}if(t.type==="variables_get")return Arduino.varTypes_&&Arduino.varTypes_[t.getFieldValue("VAR")]||"int";if(t.type==="ard_millis"||t.type==="ard_timer")return t.getFieldValue("U")==="S"?"float":"long";if(t.type==="eb_arg")return EB.argType(t);if(t.type==="ard_math1")return t.getFieldValue("OP")==="SQRT"?"float":valueType(t.getInputTargetBlock("V"));if(t.type==="math_constrain")return widest(["VALUE","LOW","HIGH"].map(i=>valueType(t.getInputTargetBlock(i))));if(t.type==="list_get")return listType(t.getFieldValue("L"));if(t.type==="list_stat"){const i=listType(t.getFieldValue("L")),a=t.getFieldValue("OP");return a==="AVG"?"float":a==="SUM"&&i==="int"?"long":i}if(t.type==="procedures_callreturn"){const i=Blockly.Procedures.getDefinition(t.getProcedureCall(),t.workspace);return i&&i.getInput("RETURN")?valueType(i.getInputTargetBlock("RETURN")):"int"}return"int"}const TYPE_RANK={int:0,long:1,float:2,String:3},listType=t=>{const i=(Arduino.listTypes_||{})[t]||"int";return i==="String"?"float":i},widest=t=>t.reduce((i,a)=>TYPE_RANK[a]>TYPE_RANK[i]?a:i,"int");function inferVarTypes(t){const i={},a=(d,l)=>{(!i[d]||TYPE_RANK[l]>TYPE_RANK[i[d]])&&(i[d]=l)},u={},m=(d,l)=>{l==="String"&&(l="float"),(!u[d]||TYPE_RANK[l]>TYPE_RANK[u[d]])&&(u[d]=l)};Arduino.listTypes_=u;for(let d=0;d<3;d++){Arduino.varTypes_=i;for(const l of t.getAllBlocks(!1))if(l.type==="list_set"||l.type==="list_push"?m(l.getFieldValue("L"),valueType(l.getInputTargetBlock("V"))):l.type==="list_init"?m(l.getFieldValue("L"),parseListNumbers(l.getFieldValue("V")).every(Number.isInteger)?"int":"float"):(l.type==="list_new"||l.type==="list_clear")&&m(l.getFieldValue("L"),"int"),l.type==="variables_set")a(l.getFieldValue("VAR"),valueType(l.getInputTargetBlock("VALUE")));else if(l.type==="ard_count")a(l.getFieldValue("VAR"),widest(["FROM","TO","STEP"].map(h=>valueType(l.getInputTargetBlock(h)))));else if(/^procedures_call/.test(l.type)){const h=Blockly.Procedures.getDefinition(l.getProcedureCall(),t);(h&&h.argumentVarModels_||[]).forEach((N,o)=>a(N.getId(),valueType(l.getInputTargetBlock("ARG"+o))))}}return i}(function(){const t=Blockly.Names.prototype.safeName_,i={ä:"ae",ö:"oe",ü:"ue",Ä:"Ae",Ö:"Oe",Ü:"Ue",ß:"ss"};Blockly.Names.prototype.safeName_=function(a){return t.call(this,a&&String(a).replace(/[äöüÄÖÜß]/g,u=>i[u]).normalize("NFD").replace(/[\u0300-\u036f]/g,""))}})();const Arduino=new Blockly.Generator("Arduino");Arduino.ORDER_ATOMIC=0,Arduino.ORDER_UNARY=3,Arduino.ORDER_MULT=5,Arduino.ORDER_ADD=6,Arduino.ORDER_REL=8,Arduino.ORDER_EQ=9,Arduino.ORDER_AND=13,Arduino.ORDER_OR=14,Arduino.ORDER_NONE=99,Arduino.INDENT="  ",Arduino.addReservedWords("setup,loop,if,else,for,while,do,int,float,long,char,byte,void,return,break,continue,true,false,HIGH,LOW,INPUT,OUTPUT,String,Serial,delay,lcd,oled,pixels,tastenfeld,taste,millis,random,tone,noTone,pinMode,digitalWrite,digitalRead,analogWrite,analogRead,map,constrain,pow,min,max,abs,motor,ultraschallLaufzeit,schrittmotor,fahrzeug,fahrzeugPins,fahrzeugEinrichten,fahrzeugFahre,schrittPhase,listenStelle,listeMittelwert,listeSumme,listeMinimum,listeMaximum,lround,labs,stoppuhrStart,neoSammeln,anzeigeStart,anzeigeBild,anzeigeText,anzeigeZahl,anzeigeLoeschen,anzeigePunkt,anzeigeLeuchtet,knopf,temperatur,lautsprecherTon,lautsprecherAus,rgbLed,Servo,lage,beschleunigung,neigung,lautstaerke,bordMotor"),Arduino.init=function(t){this.includes_={},this.globals_={},this.setupPre_={},this.helpers_={},this.functions_={},this.setupBody_="",this.loopBody_="",this.params_=new Set,this.bitmaps_={},this.nameDB_?this.nameDB_.reset():this.nameDB_=new Blockly.Names(this.RESERVED_WORDS_),this.nameDB_.setVariableMap(t.getVariableMap()),this.varTypes_=inferVarTypes(t);for(const i of t.getAllBlocks(!1))/^procedures_def/.test(i.type)&&(i.argumentVarModels_||[]).forEach(a=>this.params_.add(a.getId()))},Arduino.finish=function(){const t=this.workspace_||Blockly.getMainWorkspace(),i=Blockly.Variables.allUsedVarModels(t).filter(o=>!this.params_.has(o.getId())),a=i.filter(o=>o.type!=="Liste").map(o=>{const _=this.varTypes_[o.getId()]||"int";return`${_} ${this.nameDB_.getName(o.getId(),Blockly.VARIABLE_CATEGORY_NAME)} = ${_==="String"?'""':"0"};`});for(const o of i.filter(_=>_.type==="Liste")){let _=0;for(const f of t.getAllBlocks(!1))f.getFieldValue("L")===o.getId()&&(f.type==="list_new"&&(_=Math.max(_,Number(f.getFieldValue("N"))||1)),f.type==="list_init"&&(_=Math.max(_,parseListNumbers(f.getFieldValue("V")).length)));_=Math.max(1,Math.min(100,_||10));const T=this.nameDB_.getName(o.getId(),Blockly.VARIABLE_CATEGORY_NAME);a.push(`${listType(o.getId())} ${T}[${_}] = {0}; // Liste „${o.name}“
int ${T}_anzahl = ${_};`)}let u="";if(hasBT()&&BT_OPT.on&&(this.includes_.bt=`#include <NimBLEDevice.h>
#include <Update.h>`,this.helpers_=Object.assign({bt:btReceiverCode(btName(BT_OPT.name))},this.helpers_),this.setupPre_=Object.assign({bt:"werkstattBluetooth(); // Bluetooth-Übertragung"},this.setupPre_)),this.helpers_.web){const o=_=>_.replace(/\bdelay\(/g,"werkstattWarten(");this.setupBody_=o(this.setupBody_),this.loopBody_=o(this.loopBody_);for(const _ in this.functions_)this.functions_[_]=o(this.functions_[_])}const d=[...new Set(Object.values(this.includes_).join(`
`).split(`
`))];d.length&&d[0]&&(u+=d.join(`
`)+`

`),isNrf()&&(u+=WB_RUNTIME+`
`);const l=Object.values(this.globals_).concat(a);l.length&&(u+=l.join(`
`)+`

`);const h=Object.values(this.helpers_);h.length&&(u+=h.join(`

`)+`

`);const N=Object.values(this.functions_);return N.length&&(u+=N.join(`

`)+`

`),u+=`void setup()
{
`+Object.values(this.setupPre_).map(o=>"  "+o+`
`).join("")+this.setupBody_+`}

`,u+=`void loop()
{
`+this.loopBody_+(this.helpers_.web?`  werkstattWarten(10); // kurze Pause, Webseite bedienen
}
`:`  delay(10); // kurze Pause für stabilen Ablauf
}
`),this.nameDB_.reset(),u},Arduino.scrubNakedValue=t=>t+`;
`,Arduino.quote_=t=>'"'+String(t).replace(/\\/g,"\\\\").replace(/"/g,'\\"')+'"',Arduino.scrub_=function(t,i,a){const u=t.nextConnection&&t.nextConnection.targetBlock();return i+(a?"":this.blockToCode(u))},function(){const t=Arduino,i=(e,n,r,s)=>t.valueToCode(e,n,r||t.ORDER_NONE)||s||"0",a=(e,n)=>e.getFieldValue(n||"PIN"),u=(e,n)=>{const r="pm"+e;n==="INPUT"&&t.setupPre_[r]||(t.setupPre_[r]=`pinMode(${e}, ${n});`)},m=e=>t.nameDB_.getName(e,Blockly.VARIABLE_CATEGORY_NAME),d=e=>/^-?[\d.]+$/.test(e),l=()=>{t.includes_.lcd=`#include <Wire.h>
#include <LiquidCrystal_I2C.h>`,t.globals_.lcd="LiquidCrystal_I2C lcd(0x27, 16, 2); // unser 1602-Display, Adresse 0x27"},h=(e,n)=>{const r=i(e,n,t.ORDER_MULT);return d(r)?String(Math.round(Number(r)*1e3)):`1000 * ${r}`},N=e=>`pixels.Color(${parseInt(e.slice(1,3),16)}, ${parseInt(e.slice(3,5),16)}, ${parseInt(e.slice(5,7),16)})`,o=()=>{t.includes_.neo="#include <Adafruit_NeoPixel.h>",t.globals_.neo||(t.globals_.neo="Adafruit_NeoPixel pixels(8, 6, NEO_GRB + NEO_KHZ800);")};t.ard_main=e=>(t.workspace_=e.workspace,t.setupBody_+=t.statementToCode(e,"SETUP"),t.loopBody_+=t.statementToCode(e,"LOOP"),""),t.ard_setup=e=>(t.workspace_=e.workspace,t.setupBody_+=t.statementToCode(e,"DO"),""),t.ard_loop=e=>(t.workspace_=e.workspace,t.loopBody_+=t.statementToCode(e,"DO"),""),t.ard_wait=e=>`delay(${e.getFieldValue("UNIT")==="S"?h(e,"N"):i(e,"N")}); // Wartezeit
`,t.ard_count=e=>{const n=m(e.getFieldValue("VAR")),r=i(e,"FROM"),s=i(e,"TO"),c=i(e,"STEP",t.ORDER_NONE,"1");if(d(r)&&d(s)&&d(c)){const O=Number(s)>=Number(r),q=Math.abs(Number(c))||1;return`for (${n} = ${r}; ${n} ${O?"<=":">="} ${s}; ${n} ${O?"+=":"-="} ${q}) {
${t.statementToCode(e,"DO")}}
`}const p=t.varTypes_[e.getFieldValue("VAR")]||"int",g=t.nameDB_.getDistinctName(n+"_bis",Blockly.VARIABLE_CATEGORY_NAME),$=t.nameDB_.getDistinctName(n+"_schritt",Blockly.VARIABLE_CATEGORY_NAME);return`{
  ${p} ${g} = ${s};
  ${p} ${$} = abs(${c});
  if (${$} == 0) ${$} = 1;
  ${n} = ${r};
  if (${n} > ${g}) ${$} = -${$};
  for (; ${$} > 0 ? ${n} <= ${g} : ${n} >= ${g}; ${n} += ${$}) {
${(O=>O?t.prefixLines(O,t.INDENT):"")(t.statementToCode(e,"DO"))}  }
}
`},t.ard_wait_until=e=>`while (!(${i(e,"C",t.ORDER_NONE,"true")})) {
  delay(10); // warten, bis die Bedingung erfüllt ist
}
`;const _=()=>{t.globals_.stoppuhr="unsigned long stoppuhrStart = 0; // Stoppuhr"};t.ard_timer=e=>(_(),[e.getFieldValue("U")==="S"?"((millis() - stoppuhrStart) / 1000.0)":"(millis() - stoppuhrStart)",t.ORDER_ATOMIC]),t.ard_timer_reset=()=>(_(),`stoppuhrStart = millis();
`),t.ard_millis=e=>[e.getFieldValue("U")==="S"?"(millis() / 1000.0)":"millis()",t.ORDER_ATOMIC],t.ard_builtin_led=e=>is8266()?(u("LED_BUILTIN","OUTPUT"),`digitalWrite(LED_BUILTIN, ${e.getFieldValue("V")==="HIGH"?"LOW":"HIGH"}); // eingebaute blaue LED (leuchtet bei NIEDRIG)
`):isC5()?(u("LED_BUILTIN","OUTPUT"),`digitalWrite(LED_BUILTIN, ${e.getFieldValue("V")}); // eingebaute RGB-LED (leuchtet weiß)
`):BOARD==="esp32"?(u("2","OUTPUT"),`digitalWrite(2, ${e.getFieldValue("V")}); // eingebaute blaue LED
`):isNrf()?`anzeigePunkt(2, 2, ${e.getFieldValue("V")==="HIGH"?1:0}); // keine eigene LED: mittlere LED der Anzeige
`:(u("LED_BUILTIN","OUTPUT"),`digitalWrite(LED_BUILTIN, ${e.getFieldValue("V")});
`),t.ard_digital_write=e=>(u(a(e),"OUTPUT"),`digitalWrite(${a(e)}, ${e.getFieldValue("V")});
`),t.ard_analog_write=e=>(u(a(e),"OUTPUT"),`analogWrite(${a(e)}, ${i(e,"V")});
`),t.ard_servo=e=>{const n=a(e);return isNrf()||(t.includes_.servo=BOARD==="esp32"&&!is8266()?"#include <ESP32Servo.h>":"#include <Servo.h>"),t.globals_["servo"+n]=`Servo servo_${n};`,t.setupPre_["servo"+n]=`servo_${n}.attach(${n}, 500, 2500);`,`servo_${n}.write(${i(e,"DEG")});
`},t.ard_tone=e=>{const n=NOTES.find(r=>r[1]===e.getFieldValue("NOTE"))[0]+{0:"",1:"#","-1":"b"}[e.getFieldValue("ACC")]+e.getFieldValue("OCT");return`tone(${a(e)}, ${noteFreq(e.getFieldValue("NOTE"),e.getFieldValue("ACC"),e.getFieldValue("OCT"))}, ${h(e,"DUR")}); // Ton ${n}
`},t.ard_tone_freq=e=>`tone(${a(e)}, ${i(e,"FREQ")}, ${h(e,"DUR")});
`,t.ard_motor=e=>{const n=a(e,"IA"),r=a(e,"IB");return u(n,"OUTPUT"),u(r,"OUTPUT"),t.helpers_.motor=`// Motortreiber L298N (IN1/IN2 bzw. IN3/IN4): richtung 1 = vorwärts, -1 = rückwärts, 0 = anhalten
void motor(int ia, int ib, int richtung, int prozent)
{
  int pwm = constrain(prozent, 0, 100) * 255 / 100;
  analogWrite(ia, richtung < 0 ? pwm : 0); // rückwärts: IN1 (bzw. IN3)
  analogWrite(ib, richtung > 0 ? pwm : 0); // vorwärts: IN2 (bzw. IN4)
}`,`motor(${n}, ${r}, ${e.getFieldValue("DIR")}, ${i(e,"SPEED")});
`};const T=()=>{t.helpers_.motor=`// Motortreiber L298N (IN1/IN2 bzw. IN3/IN4): richtung 1 = vorwärts, -1 = rückwärts, 0 = anhalten
void motor(int ia, int ib, int richtung, int prozent)
{
  int pwm = constrain(prozent, 0, 100) * 255 / 100;
  analogWrite(ia, richtung < 0 ? pwm : 0); // rückwärts: IN1 (bzw. IN3)
  analogWrite(ib, richtung > 0 ? pwm : 0); // vorwärts: IN2 (bzw. IN4)
}`,t.helpers_.zcar=`// Fahrzeug mit zwei Motoren: je Seite -100 (voll rückwärts) bis 100 (voll vorwärts)
int fahrzeugPins[4] = {-1, -1, -1, -1};
void fahrzeugEinrichten(int la, int lb, int ra, int rb)
{
  fahrzeugPins[0] = la; fahrzeugPins[1] = lb; fahrzeugPins[2] = ra; fahrzeugPins[3] = rb;
  for (int i = 0; i < 4; i++) pinMode(fahrzeugPins[i], OUTPUT);
}
void fahrzeug(int links, int rechts)
{
  if (fahrzeugPins[0] < 0) return; // „Fahrzeug einrichten“ fehlt
  links = constrain(links, -100, 100); rechts = constrain(rechts, -100, 100);
  motor(fahrzeugPins[0], fahrzeugPins[1], links > 0 ? 1 : (links < 0 ? -1 : 0), abs(links));
  // der rechte Motor ist um 180° gedreht eingebaut: vorwärts heißt für ihn rückwärts
  motor(fahrzeugPins[2], fahrzeugPins[3], rechts > 0 ? -1 : (rechts < 0 ? 1 : 0), abs(rechts));
}
// art: 0 vorwärts, 1 rückwärts, 2 Linkskurve, 3 Rechtskurve, 4 links drehen, 5 rechts drehen
void fahrzeugFahre(int art, int tempo)
{
  tempo = constrain(tempo, 0, 100);
  int k = (tempo + 1) / 3; // inneres Rad in der Kurve
  switch (art) {
    case 0: fahrzeug(tempo, tempo); break;
    case 1: fahrzeug(-tempo, -tempo); break;
    case 2: fahrzeug(k, tempo); break;
    case 3: fahrzeug(tempo, k); break;
    case 4: fahrzeug(-tempo, tempo); break;
    case 5: fahrzeug(tempo, -tempo); break;
  }
}`};t.car_init=e=>(T(),`fahrzeugEinrichten(${["LA","LB","RA","RB"].map(n=>a(e,n)).join(", ")});
`),t.car_drive=e=>(T(),`fahrzeugFahre(${{FWD:0,BWD:1,CL:2,CR:3,TL:4,TR:5}[e.getFieldValue("DIR")]}, ${i(e,"SPEED")}); // ${e.getField("DIR").getText()}
`),t.car_stop=()=>(T(),`fahrzeug(0, 0); // anhalten
`),t.car_motors=e=>(T(),`fahrzeug(${i(e,"L")}, ${i(e,"R")});
`),t.ard_stepper=e=>{t.helpers_.stepper=`// Schrittmotor 28BYJ-48 mit Treiber ULN2003: 2048 Schritte = 1 Umdrehung, höchstens 15 U/min
int schrittPhase[40];
void schrittmotor(int in1, int in2, int in3, int in4, long schritte, float upm)
{
  const byte spulen[4][4] = {{1, 1, 0, 0}, {0, 1, 1, 0}, {0, 0, 1, 1}, {1, 0, 0, 1}};
  int pins[4] = {in1, in2, in3, in4};
  for (int i = 0; i < 4; i++) pinMode(pins[i], OUTPUT);
  upm = constrain(upm, 1, 15);
  unsigned long pause = (unsigned long)(60000000.0 / (2048.0 * upm)); // Mikrosekunden je Schritt
  int richtung = schritte < 0 ? -1 : 1;
  int &phase = schrittPhase[in1 % 40];
  for (long s = 0; s < labs(schritte); s++) {
    phase = (phase + richtung + 4) % 4;
    for (int i = 0; i < 4; i++) digitalWrite(pins[i], spulen[phase][i]);
    delayMicroseconds(pause % 1000);
    delay(pause / 1000);
  }
  for (int i = 0; i < 4; i++) digitalWrite(pins[i], LOW); // Spulen aus, damit nichts warm wird
}`;const n=[1,2,3,4].map(p=>a(e,"P"+p)).join(", "),r=i(e,"N",t.ORDER_MULT),s=e.getFieldValue("UNIT");let c=s==="STEP"?r:s==="REV"?`${r} * 2048`:`${r} * 2048.0 / 360.0`;return d(r)?c=String(Math.round(Number(r)*(s==="STEP"?1:s==="REV"?2048:2048/360))):c=`lround(${c})`,e.getFieldValue("DIR")==="CCW"&&(c=d(c)?"-"+c:`-(${c})`),`schrittmotor(${n}, ${c}, ${i(e,"RPM",t.ORDER_NONE,"10")}); // ${{DEG:"Grad",REV:"Umdrehungen",STEP:"Schritte"}[s]}, ${e.getFieldValue("DIR")==="CCW"?"gegen den Uhrzeigersinn":"im Uhrzeigersinn"}
`},t.ard_dht=e=>{const n=a(e),r=e.getFieldValue("MODEL");t.includes_.dht="#include <DHT.h>",t.globals_["dht"+n]=`DHT dht_${n}(${n}, DHT${r}); // Temperatur- und Feuchtesensor DHT${r}`,t.setupPre_["dht"+n]=`dht_${n}.begin();`;const s=e.getFieldValue("WHAT");return[s==="H"?`dht_${n}.readHumidity()`:`dht_${n}.readTemperature(${s==="F"?"true":""})`,t.ORDER_ATOMIC]};const f=e=>m(e.getFieldValue("L")),L=()=>{t.helpers_.listPos=`// Listen: Nummer 1 … Anzahl in die Stelle 0 … Anzahl-1 umrechnen (außerhalb: erster bzw. letzter Eintrag)
int listenStelle(long nummer, int anzahl)
{
  if (nummer < 1 || anzahl < 1) return 0;
  if (nummer > anzahl) return anzahl - 1;
  return nummer - 1;
}`};t.list_new=e=>{const n=f(e),r=Math.max(1,Math.min(100,Number(e.getFieldValue("N"))||1));return`${n}_anzahl = ${r};
for (int i = 0; i < ${r}; i++) ${n}[i] = 0;
`},t.list_init=e=>{const n=f(e),r=parseListNumbers(e.getFieldValue("V"));return`${n}_anzahl = ${r.length};
`+r.map((s,c)=>`${n}[${c}] = ${s};`).join(" ")+(r.length?`
`:"")},t.list_get=e=>{L();const n=f(e);return[`${n}[listenStelle(${i(e,"I",t.ORDER_NONE,"1")}, ${n}_anzahl)]`,t.ORDER_ATOMIC]},t.list_set=e=>{L();const n=f(e);return`${n}[listenStelle(${i(e,"I",t.ORDER_NONE,"1")}, ${n}_anzahl)] = ${i(e,"V")};
`},t.list_push=e=>{const n=f(e);return`for (int i = 0; i + 1 < ${n}_anzahl; i++) ${n}[i] = ${n}[i + 1]; // alle eins nach vorne
if (${n}_anzahl > 0) ${n}[${n}_anzahl - 1] = ${i(e,"V")};
`},t.list_clear=e=>{const n=f(e);return`for (int i = 0; i < ${n}_anzahl; i++) ${n}[i] = 0; // Liste leeren
`},t.list_len=e=>[`${f(e)}_anzahl`,t.ORDER_ATOMIC],t.list_stat=e=>{const n=listType(e.getFieldValue("L")),r=e.getFieldValue("OP"),s=n==="int"?"long":n,c={AVG:`float listeMittelwert(const ${n} *liste, int anzahl)
{
  float summe = 0;
  for (int i = 0; i < anzahl; i++) summe += liste[i];
  return anzahl > 0 ? summe / anzahl : 0;
}`,SUM:`${s} listeSumme(const ${n} *liste, int anzahl)
{
  ${s} summe = 0;
  for (int i = 0; i < anzahl; i++) summe += liste[i];
  return summe;
}`,MIN:`${n} listeMinimum(const ${n} *liste, int anzahl)
{
  ${n} m = liste[0];
  for (int i = 1; i < anzahl; i++) if (liste[i] < m) m = liste[i];
  return m;
}`,MAX:`${n} listeMaximum(const ${n} *liste, int anzahl)
{
  ${n} m = liste[0];
  for (int i = 1; i < anzahl; i++) if (liste[i] > m) m = liste[i];
  return m;
}`};return t.helpers_["list"+r+n]=c[r],[`${{AVG:"listeMittelwert",SUM:"listeSumme",MIN:"listeMinimum",MAX:"listeMaximum"}[r]}(${f(e)}, ${f(e)}_anzahl)`,t.ORDER_ATOMIC]},t.ard_round=e=>[`(long)${{ROUND:"round",UP:"ceil",DOWN:"floor"}[e.getFieldValue("OP")]}(${i(e,"V")})`,t.ORDER_UNARY],t.ard_math1=e=>[e.getFieldValue("OP")==="ABS"?`fabs(${i(e,"V")})`:`sqrt(${i(e,"V")})`,t.ORDER_ATOMIC],t.ard_notone=e=>`noTone(${a(e)});
`,t.ard_serial=e=>(t.setupPre_.serial=BOARD==="esp32"||isNrf()?"Serial.begin(115200);":"Serial.begin(9600);",`Serial.${e.getFieldValue("NL")==="Y"?"println":"print"}(${i(e,"V",t.ORDER_NONE,'""')});
`),t.ard_lcd_init=()=>(l(),`lcd.init();
`),t.ard_lcd_backlight=e=>(l(),e.getFieldValue("ON")==="1"?`lcd.backlight();
`:`lcd.noBacklight();
`),t.ard_lcd_clear=()=>(l(),`lcd.clear();
`),t.ard_lcd_print=e=>(l(),`lcd.print(${t.charmap_(i(e,"V",t.ORDER_NONE,'""'),t.lcdChars_)});
`),t.ard_lcd_pos=e=>(l(),`lcd.setCursor(${i(e,"COL")}, ${i(e,"ROW")});
`),t.ard_join=e=>[`String(${i(e,"A",t.ORDER_NONE,'""')}) + String(${i(e,"B",t.ORDER_NONE,'""')})`,t.ORDER_ADD],t.ard_digital_read=e=>(u(a(e),"INPUT"),[`digitalRead(${a(e)})`,t.ORDER_ATOMIC]);const C=e=>e.getFieldValue("PIN").replace(/^D/,"");t.ard_analog_read=e=>[`analogRead(${C(e)})`,t.ORDER_ATOMIC],t.ard_tmp36=e=>{const n=is8266()?"((analogRead(A0) * 3.3 / 1023.0 - 0.5) * 100.0)":BOARD==="esp32"?`((analogReadMilliVolts(${C(e)}) / 1000.0 - 0.5) * 100.0)`:`((analogRead(${C(e)}) * 5.0 / 1023.0 - 0.5) * 100.0)`;return[e.getFieldValue("UNIT")==="C"?n:`(${n} * 9.0 / 5.0 + 32.0)`,t.ORDER_ATOMIC]},t.ard_ultrasonic=e=>(t.helpers_.us=`long ultraschallLaufzeit(int trigger, int echo)
{
  pinMode(trigger, OUTPUT);
  digitalWrite(trigger, LOW);
  delayMicroseconds(2);
  digitalWrite(trigger, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigger, LOW);
  pinMode(echo, INPUT);
  return pulseIn(echo, HIGH);
}`,[`(${e.getFieldValue("UNIT")==="CM"?"0.01723":"0.00675"} * ultraschallLaufzeit(${a(e,"TRIG")}, ${a(e,"ECHO")}))`,t.ORDER_ATOMIC]),t.ard_map=e=>[`map(${i(e,"V")}, ${i(e,"A")}, ${i(e,"B")}, ${i(e,"C")}, ${i(e,"D")})`,t.ORDER_ATOMIC],t.neo_init=e=>(o(),t.globals_.neo=`Adafruit_NeoPixel pixels(${Number(e.getFieldValue("N"))||1}, ${a(e)}, NEO_GRB + NEO_KHZ800);`,`pixels.begin();
pixels.clear();
pixels.show();
`);const D=e=>e.workspace.getBlocksByType("neo_hold",!1).length?`if (!neoSammeln) pixels.show();
`:`pixels.show();
`,U=()=>{t.globals_.neoSammeln="bool neoSammeln = false; // NeoPixel: Änderungen erst bei „anzeigen“ zeigen"};t.neo_set=e=>(o(),`pixels.setPixelColor(${i(e,"I",t.ORDER_ADD)} - 1, ${N(e.getFieldValue("C"))});
`+D(e)),t.neo_set_rgb=e=>(o(),`pixels.setPixelColor(${i(e,"I",t.ORDER_ADD)} - 1, pixels.Color(${i(e,"R")}, ${i(e,"G")}, ${i(e,"B")}));
`+D(e)),t.neo_fill=e=>(o(),`pixels.fill(${N(e.getFieldValue("C"))});
`+D(e)),t.neo_brightness=e=>(o(),`pixels.setBrightness(${i(e,"V")});
`+D(e)),t.neo_clear=e=>(o(),`pixels.clear();
`+D(e)),t.neo_hold=()=>(o(),U(),`neoSammeln = true;
`),t.neo_show=()=>(o(),`pixels.show();
`);const M=(e,n)=>{const r=KEYMAP[n].map(p=>"{"+p.map(g=>`'${g}'`).join(", ")+"}").join(", "),s=[0,1,2,3].map(p=>e.getFieldValue("R"+p)).join(", "),c=Array.from({length:n},(p,g)=>e.getFieldValue("C"+g)).join(", ");return t.includes_.kp="#include <Keypad.h>",t.globals_.kp=`char tf_tasten[4][${n}] = {${r}};
byte tf_zeilen[4] = {${s}};
byte tf_spalten[${n}] = {${c}};
Keypad tastenfeld = Keypad(makeKeymap(tf_tasten), tf_zeilen, tf_spalten, 4, ${n});
String taste = "";`,""};t.kp_init3=e=>M(e,3),t.kp_init4=e=>M(e,4),t.kp_read=()=>`{
  char k = tastenfeld.getKey();
  taste = k ? String(k) : String("");
}
`,t.kp_key=()=>["taste",t.ORDER_ATOMIC];const E=()=>{t.includes_.oled=`#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>`,t.globals_.oled="Adafruit_SSD1306 oled(128, 64, &Wire, -1); // OLED 128 x 64, I2C-Adresse 0x3C"},w=e=>e.getFieldValue("C")==="1"?"SSD1306_WHITE":"SSD1306_BLACK";t.oled_init=()=>(E(),`oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
oled.cp437(true); // Umlaute
oled.clearDisplay();
oled.setTextColor(SSD1306_WHITE);
oled.display();
`),t.oled_clear=()=>(E(),`oled.clearDisplay();
`),t.oled_show=()=>(E(),`oled.display();
`),t.oled_cursor=e=>(E(),`oled.setCursor(${i(e,"X")}, ${i(e,"Y")});
`),t.oled_size=e=>(E(),`oled.setTextSize(${e.getFieldValue("N")});
`),t.oled_print=e=>(E(),`oled.print(${t.charmap_(i(e,"V",t.ORDER_NONE,'""'),t.oledChars_)});
`),t.oled_pixel=e=>(E(),`oled.drawPixel(${i(e,"X")}, ${i(e,"Y")}, ${w(e)});
`),t.oled_line=e=>(E(),`oled.drawLine(${i(e,"X0")}, ${i(e,"Y0")}, ${i(e,"X1")}, ${i(e,"Y1")}, ${w(e)});
`),t.oled_rect=e=>(E(),`oled.${e.getFieldValue("F")==="1"?"fillRect":"drawRect"}(${i(e,"X")}, ${i(e,"Y")}, ${i(e,"W")}, ${i(e,"H")}, ${w(e)});
`),t.oled_circle=e=>(E(),`oled.${e.getFieldValue("F")==="1"?"fillCircle":"drawCircle"}(${i(e,"X")}, ${i(e,"Y")}, ${i(e,"R")}, ${w(e)});
`),t.oled_bitmap=e=>{E();const n=Bitmap.parse(e.getFieldValue("BMP"));t.bitmaps_=t.bitmaps_||{};let r=t.bitmaps_[n.d];if(!r){r="bild_"+(Object.keys(t.bitmaps_).length+1),t.bitmaps_[n.d]=r;const s=n.d.match(/../g).map(g=>"0x"+g),c=[],p=Math.ceil(n.w/8);for(let g=0;g<s.length;g+=p*Math.max(1,Math.floor(16/p)))c.push("  "+s.slice(g,g+p*Math.max(1,Math.floor(16/p))).join(", "));t.globals_["bmp"+r]=`// Bild ${n.w} x ${n.h} Pixel (Grafikeditor)
const unsigned char ${r}[] PROGMEM = {
${c.join(`,
`)}
};`}return`oled.drawBitmap(${i(e,"X")}, ${i(e,"Y")}, ${r}, ${n.w}, ${n.h}, ${w(e)});
`};const I=e=>"ads_"+e.slice(2),z=(e,n)=>e.replace(/[äöüÄÖÜß°]/g,r=>n[r]?"\\"+n[r].toString(8):r);t.oledChars_={ä:132,ö:148,ü:129,Ä:142,Ö:153,Ü:154,ß:225,"°":248},t.lcdChars_={ä:225,ö:239,ü:245,ß:226,"°":223},t.charmap_=z,t.init_voltmeter_i2c=e=>{const n=e.getFieldValue("ADDRESS");t.includes_.ads="#include <Adafruit_ADS1X15.h>",t.globals_["ads"+n]=`Adafruit_ADS1115 ${I(n)};`;const r={6:"GAIN_TWOTHIRDS",4:"GAIN_ONE",2:"GAIN_TWO",1:"GAIN_FOUR"}[e.getFieldValue("RANGE")];return`${I(n)}.begin(${n});
${I(n)}.setGain(${r});
`},t.read_voltmeter_differential=e=>{const n=I(e.getFieldValue("ADDRESS"));return[`${n}.computeVolts(${n}.readADC_Differential_${e.getFieldValue("KANAL")==="0"?"0_1":"2_3"}())`,t.ORDER_ATOMIC]},t.read_voltmeter_channel=e=>{const n=I(e.getFieldValue("ADDRESS"));return[`${n}.computeVolts(${n}.readADC_SingleEnded(${e.getFieldValue("KANAL")}))`,t.ORDER_ATOMIC]},t.calculate_pmfc_power=e=>{const n=i(e,"VOLTAGE",t.ORDER_NONE),r=e.getFieldValue("RESISTOR"),s=e.getFieldValue("OUTPUT_TYPE");return[s==="MA"?`((${n}) / ${r}.0 * 1000.0)`:`(pow(${n}, 2) / ${r}.0 * ${s==="UW"?"1000000.0":"1000.0"})`,t.ORDER_ATOMIC]};const b=e=>"ina_"+e.slice(2);t.init_ina219_i2c=e=>{const n=e.getFieldValue("ADDRESS");return t.includes_.ina="#include <Adafruit_INA219.h>",t.globals_["ina"+n]=`Adafruit_INA219 ${b(n)}(${n});`,`${b(n)}.begin();
${b(n)}.setCalibration_${e.getFieldValue("CALIBRATION")}();
`},t.read_ina219_value=e=>{const n=b(e.getFieldValue("ADDRESS"));return[{CURRENT:`${n}.getCurrent_mA()`,BUS_VOLT:`${n}.getBusVoltage_V()`,SHUNT_VOLT:`${n}.getShuntVoltage_mV()`}[e.getFieldValue("MEASURE_MODE")],t.ORDER_ATOMIC]};const G=String.raw`// Über USB empfangen (serieller Monitor)
String usbText = "";
bool usbEmpfangen()
{
  if (Serial.available() > 0) {
    usbText = Serial.readStringUntil('\n');
    usbText.trim();
    return true;
  }
  return false;
}`,H=String.raw`// WLAN
void wlanVerbinden(String name, String passwort)
{
  WiFi.mode(WIFI_STA);
  WiFi.begin(name.c_str(), passwort.c_str());
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 15000) delay(200);
}

void wlanOeffnen(String name, String passwort)
{
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAP(name.c_str(), passwort.length() >= 8 ? passwort.c_str() : NULL);
}

bool wlanVerbunden()
{
  return WiFi.status() == WL_CONNECTED || (WiFi.getMode() & WIFI_AP);
}

String eigeneIP()
{
  if (WiFi.status() == WL_CONNECTED) return WiFi.localIP().toString();
  if (WiFi.getMode() & WIFI_AP) return WiFi.softAPIP().toString();
  return "0.0.0.0";
}`,j=String.raw(y||(y=x([`// Eigene Webseite: Werte anzeigen, Knöpfe und Schieberegler
WebServer webServer(80);
String webTitel = "ESP32";
const int WEB_MAX = 12;
String webWertName[WEB_MAX], webWert[WEB_MAX], webKnopfName[WEB_MAX], webReglerName[WEB_MAX];
bool webKnopfDruck[WEB_MAX];
int webReglerWert[WEB_MAX];
int webWerte = 0, webKnoepfe = 0, webRegler = 0;

int webPlatz(String *namen, int &anzahl, const String &name)
{
  for (int i = 0; i < anzahl; i++) if (namen[i] == name) return i;
  if (anzahl >= WEB_MAX) return -1;
  namen[anzahl] = name;
  return anzahl++;
}

void webAnzeigen(const String &name, const String &wert)
{
  int i = webPlatz(webWertName, webWerte, name);
  if (i >= 0) webWert[i] = wert;
}

bool webKnopf(const String &name)
{
  int i = webPlatz(webKnopfName, webKnoepfe, name);
  if (i < 0 || !webKnopfDruck[i]) return false;
  webKnopfDruck[i] = false;
  return true;
}

int webSchieberegler(const String &name)
{
  int i = webPlatz(webReglerName, webRegler, name);
  return i < 0 ? 0 : webReglerWert[i];
}

String webJson(const String &s)
{
  String r = """;
  for (unsigned int i = 0; i < s.length(); i++) {
    char c = s[i];
    if ((unsigned char)c < 32) continue;
    if (c == '"' || c == '\\') r += '\\';
    r += c;
  }
  return r + """;
}

void webDaten()
{
  String j = "{"titel":" + webJson(webTitel) + ","werte":[";
  for (int i = 0; i < webWerte; i++) j += String(i ? "," : "") + "[" + webJson(webWertName[i]) + "," + webJson(webWert[i]) + "]";
  j += "],"knoepfe":[";
  for (int i = 0; i < webKnoepfe; i++) j += String(i ? "," : "") + webJson(webKnopfName[i]);
  j += "],"regler":[";
  for (int i = 0; i < webRegler; i++) j += String(i ? "," : "") + "[" + webJson(webReglerName[i]) + "," + String(webReglerWert[i]) + "]";
  j += "]}";
  webServer.sendHeader("Cache-Control", "no-store");
  webServer.send(200, "application/json", j);
}

const char WEB_SEITE[] PROGMEM = R"seite(<!DOCTYPE html><html lang="de"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>ESP32</title>
<style>body{font-family:system-ui,sans-serif;margin:0;background:#f3f5f2;color:#222}h1{margin:0;padding:16px;background:#137a7f;color:#fff;font-size:22px}
main{padding:12px;max-width:520px;margin:auto}.k{background:#fff;border-radius:10px;padding:12px 14px;margin:10px 0;box-shadow:0 1px 3px #0002;display:flex;justify-content:space-between;align-items:center;gap:10px}
.k b{font-size:20px}button{font:inherit;font-size:18px;padding:12px;border:0;border-radius:10px;background:#137a7f;color:#fff;width:100%;margin:6px 0}input{width:100%}</style></head>
<body><h1 id="t">ESP32</h1><main><div id="w"></div><div id="s"></div></main><script>
var bau = '';
function el(t, c, x) { var e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; }
function lade() {
  fetch('/daten', { cache: 'no-store' }).then(function (r) { return r.json(); }).then(function (d) {
    document.getElementById('t').textContent = d.titel; document.title = d.titel;
    var w = document.getElementById('w'); w.innerHTML = '';
    d.werte.forEach(function (p) { var k = el('div', 'k'); k.appendChild(el('span', '', p[0])); k.appendChild(el('b', '', p[1])); w.appendChild(k); });
    var neu = JSON.stringify([d.knoepfe, d.regler.map(function (r) { return r[0]; })]);
    if (neu === bau) return;
    bau = neu; var s = document.getElementById('s'); s.innerHTML = '';
    d.knoepfe.forEach(function (n, i) { var b = el('button', '', n); b.onclick = function () { fetch('/knopf?i=' + i + '&t=' + Date.now(), { cache: 'no-store' }); }; s.appendChild(b); });
    d.regler.forEach(function (r, i) {
      var k = el('div', 'k'), v = el('b', '', r[1]), e = el('input');
      k.appendChild(el('span', '', r[0])); k.appendChild(v);
      e.type = 'range'; e.min = 0; e.max = 100; e.value = r[1];
      e.oninput = function () { v.textContent = e.value; };
      e.onchange = function () { fetch('/regler?i=' + i + '&w=' + e.value + '&t=' + Date.now(), { cache: 'no-store' }); };
      s.appendChild(k); s.appendChild(e);
    });
  }).catch(function () {});
}
lade(); setInterval(lade, 1000);
<\/script></body></html>)seite";

void webStarten(const String &titel)
{
  webTitel = titel;
  webServer.on("/", []() { webServer.send_P(200, "text/html", WEB_SEITE); });
  webServer.on("/daten", webDaten);
  webServer.on("/knopf", []() {
    int i = webServer.arg("i").toInt();
    if (i >= 0 && i < webKnoepfe) webKnopfDruck[i] = true;
    webServer.send(200, "text/plain", "ok");
  });
  webServer.on("/regler", []() {
    int i = webServer.arg("i").toInt();
    if (i >= 0 && i < webRegler) webReglerWert[i] = constrain(webServer.arg("w").toInt(), 0, 100);
    webServer.send(200, "text/plain", "ok");
  });
  webServer.begin();
}

// Warten, währenddessen die Webseite weiter beantworten
void werkstattWarten(unsigned long ms)
{
  unsigned long start = millis();
  do {
    webServer.handleClient();
    delay(1);
  } while (millis() - start < ms);
}`],[`// Eigene Webseite: Werte anzeigen, Knöpfe und Schieberegler
WebServer webServer(80);
String webTitel = "ESP32";
const int WEB_MAX = 12;
String webWertName[WEB_MAX], webWert[WEB_MAX], webKnopfName[WEB_MAX], webReglerName[WEB_MAX];
bool webKnopfDruck[WEB_MAX];
int webReglerWert[WEB_MAX];
int webWerte = 0, webKnoepfe = 0, webRegler = 0;

int webPlatz(String *namen, int &anzahl, const String &name)
{
  for (int i = 0; i < anzahl; i++) if (namen[i] == name) return i;
  if (anzahl >= WEB_MAX) return -1;
  namen[anzahl] = name;
  return anzahl++;
}

void webAnzeigen(const String &name, const String &wert)
{
  int i = webPlatz(webWertName, webWerte, name);
  if (i >= 0) webWert[i] = wert;
}

bool webKnopf(const String &name)
{
  int i = webPlatz(webKnopfName, webKnoepfe, name);
  if (i < 0 || !webKnopfDruck[i]) return false;
  webKnopfDruck[i] = false;
  return true;
}

int webSchieberegler(const String &name)
{
  int i = webPlatz(webReglerName, webRegler, name);
  return i < 0 ? 0 : webReglerWert[i];
}

String webJson(const String &s)
{
  String r = "\\"";
  for (unsigned int i = 0; i < s.length(); i++) {
    char c = s[i];
    if ((unsigned char)c < 32) continue;
    if (c == '"' || c == '\\\\') r += '\\\\';
    r += c;
  }
  return r + "\\"";
}

void webDaten()
{
  String j = "{\\"titel\\":" + webJson(webTitel) + ",\\"werte\\":[";
  for (int i = 0; i < webWerte; i++) j += String(i ? "," : "") + "[" + webJson(webWertName[i]) + "," + webJson(webWert[i]) + "]";
  j += "],\\"knoepfe\\":[";
  for (int i = 0; i < webKnoepfe; i++) j += String(i ? "," : "") + webJson(webKnopfName[i]);
  j += "],\\"regler\\":[";
  for (int i = 0; i < webRegler; i++) j += String(i ? "," : "") + "[" + webJson(webReglerName[i]) + "," + String(webReglerWert[i]) + "]";
  j += "]}";
  webServer.sendHeader("Cache-Control", "no-store");
  webServer.send(200, "application/json", j);
}

const char WEB_SEITE[] PROGMEM = R"seite(<!DOCTYPE html><html lang="de"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>ESP32</title>
<style>body{font-family:system-ui,sans-serif;margin:0;background:#f3f5f2;color:#222}h1{margin:0;padding:16px;background:#137a7f;color:#fff;font-size:22px}
main{padding:12px;max-width:520px;margin:auto}.k{background:#fff;border-radius:10px;padding:12px 14px;margin:10px 0;box-shadow:0 1px 3px #0002;display:flex;justify-content:space-between;align-items:center;gap:10px}
.k b{font-size:20px}button{font:inherit;font-size:18px;padding:12px;border:0;border-radius:10px;background:#137a7f;color:#fff;width:100%;margin:6px 0}input{width:100%}</style></head>
<body><h1 id="t">ESP32</h1><main><div id="w"></div><div id="s"></div></main><script>
var bau = '';
function el(t, c, x) { var e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; }
function lade() {
  fetch('/daten', { cache: 'no-store' }).then(function (r) { return r.json(); }).then(function (d) {
    document.getElementById('t').textContent = d.titel; document.title = d.titel;
    var w = document.getElementById('w'); w.innerHTML = '';
    d.werte.forEach(function (p) { var k = el('div', 'k'); k.appendChild(el('span', '', p[0])); k.appendChild(el('b', '', p[1])); w.appendChild(k); });
    var neu = JSON.stringify([d.knoepfe, d.regler.map(function (r) { return r[0]; })]);
    if (neu === bau) return;
    bau = neu; var s = document.getElementById('s'); s.innerHTML = '';
    d.knoepfe.forEach(function (n, i) { var b = el('button', '', n); b.onclick = function () { fetch('/knopf?i=' + i + '&t=' + Date.now(), { cache: 'no-store' }); }; s.appendChild(b); });
    d.regler.forEach(function (r, i) {
      var k = el('div', 'k'), v = el('b', '', r[1]), e = el('input');
      k.appendChild(el('span', '', r[0])); k.appendChild(v);
      e.type = 'range'; e.min = 0; e.max = 100; e.value = r[1];
      e.oninput = function () { v.textContent = e.value; };
      e.onchange = function () { fetch('/regler?i=' + i + '&w=' + e.value + '&t=' + Date.now(), { cache: 'no-store' }); };
      s.appendChild(k); s.appendChild(e);
    });
  }).catch(function () {});
}
lade(); setInterval(lade, 1000);
<\/script></body></html>)seite";

void webStarten(const String &titel)
{
  webTitel = titel;
  webServer.on("/", []() { webServer.send_P(200, "text/html", WEB_SEITE); });
  webServer.on("/daten", webDaten);
  webServer.on("/knopf", []() {
    int i = webServer.arg("i").toInt();
    if (i >= 0 && i < webKnoepfe) webKnopfDruck[i] = true;
    webServer.send(200, "text/plain", "ok");
  });
  webServer.on("/regler", []() {
    int i = webServer.arg("i").toInt();
    if (i >= 0 && i < webRegler) webReglerWert[i] = constrain(webServer.arg("w").toInt(), 0, 100);
    webServer.send(200, "text/plain", "ok");
  });
  webServer.begin();
}

// Warten, währenddessen die Webseite weiter beantworten
void werkstattWarten(unsigned long ms)
{
  unsigned long start = millis();
  do {
    webServer.handleClient();
    delay(1);
  } while (millis() - start < ms);
}`]))),K=String.raw`// Funk zwischen ESP32 (ESP-NOW, ohne WLAN-Router)
uint8_t funkGruppe = 1;
volatile bool funkNeu = false;
char funkPuffer[201];
String funkText = "";

#if ESP_ARDUINO_VERSION_MAJOR >= 3
void funkEmpfang(const esp_now_recv_info_t *info, const uint8_t *daten, int n)
#else
void funkEmpfang(const uint8_t *mac, const uint8_t *daten, int n)
#endif
{
  if (n < 1 || daten[0] != funkGruppe || funkNeu) return;
  n = n - 1;
  if (n > 200) n = 200;
  memcpy(funkPuffer, daten + 1, n);
  funkPuffer[n] = 0;
  funkNeu = true;
}

void funkEinrichten(int gruppe)
{
  funkGruppe = gruppe;
  if (WiFi.getMode() == WIFI_MODE_NULL) WiFi.mode(WIFI_STA);
  esp_now_init();
  esp_now_register_recv_cb(funkEmpfang);
  esp_now_peer_info_t partner = {};
  memset(partner.peer_addr, 0xFF, 6);
  partner.channel = 0;
  partner.encrypt = false;
  esp_now_add_peer(&partner);
}

void funkSenden(const String &text)
{
  uint8_t puffer[201];
  int n = text.length();
  if (n > 199) n = 199;
  puffer[0] = funkGruppe;
  memcpy(puffer + 1, text.c_str(), n);
  uint8_t alle[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
  esp_now_send(alle, puffer, n + 1);
}

bool funkEmpfangen()
{
  if (!funkNeu) return false;
  funkText = String(funkPuffer);
  funkNeu = false;
  return true;
}`,Y=String.raw`// Funk zwischen ESP8266 und ESP32 (ESP-NOW, ohne WLAN-Router)
uint8_t funkGruppe = 1;
volatile bool funkNeu = false;
char funkPuffer[201];
String funkText = "";

void funkEmpfang(uint8_t *mac, uint8_t *daten, uint8_t n)
{
  if (n < 1 || daten[0] != funkGruppe || funkNeu) return;
  n = n - 1;
  if (n > 200) n = 200;
  memcpy(funkPuffer, daten + 1, n);
  funkPuffer[n] = 0;
  funkNeu = true;
}

void funkEinrichten(int gruppe)
{
  funkGruppe = gruppe;
  if (WiFi.getMode() == WIFI_OFF) WiFi.mode(WIFI_STA);
  esp_now_init();
  esp_now_set_self_role(ESP_NOW_ROLE_COMBO);
  esp_now_register_recv_cb(funkEmpfang);
  uint8_t alle[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
  esp_now_add_peer(alle, ESP_NOW_ROLE_COMBO, 0, NULL, 0);
}

void funkSenden(const String &text)
{
  uint8_t puffer[201];
  int n = text.length();
  if (n > 199) n = 199;
  puffer[0] = funkGruppe;
  memcpy(puffer + 1, text.c_str(), n);
  uint8_t alle[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
  esp_now_send(alle, puffer, n + 1);
}

bool funkEmpfangen()
{
  if (!funkNeu) return false;
  funkText = String(funkPuffer);
  funkNeu = false;
  return true;
}`,v=()=>is8266()?"#include <ESP8266WiFi.h>":"#include <WiFi.h>",F=()=>{t.setupPre_.serial="Serial.begin(115200);",t.helpers_.usb=G},k=()=>{t.includes_.wifi=v(),t.helpers_.wifi=H},B=()=>{t.includes_.wifi=v(),t.includes_.web=is8266()?`#include <ESP8266WebServer.h>
using WebServer = ESP8266WebServer;`:"#include <WebServer.h>",t.helpers_.web=j},A=()=>{t.includes_.wifi=v(),t.includes_.radio=is8266()?"#include <espnow.h>":"#include <esp_now.h>",t.helpers_.radio=is8266()?Y:K},R=(e,n)=>`String(${i(e,n,t.ORDER_NONE,'""')})`;t.com_usb_avail=()=>(F(),["usbEmpfangen()",t.ORDER_ATOMIC]),t.com_usb_text=()=>(F(),["usbText",t.ORDER_ATOMIC]),t.com_usb_num=()=>(F(),["usbText.toFloat()",t.ORDER_ATOMIC]),t.com_wifi_connect=e=>(k(),`wlanVerbinden(${R(e,"SSID")}, ${R(e,"PW")});
`),t.com_wifi_ap=e=>(k(),`wlanOeffnen(${R(e,"SSID")}, ${R(e,"PW")});
`),t.com_wifi_ok=()=>(k(),["wlanVerbunden()",t.ORDER_ATOMIC]),t.com_wifi_ip=()=>(k(),["eigeneIP()",t.ORDER_ATOMIC]),t.com_web_start=e=>(B(),`webStarten(${R(e,"T")});
`),t.com_web_show=e=>(B(),`webAnzeigen(${t.quote_(e.getFieldValue("N"))}, ${R(e,"V")});
`),t.com_web_button=e=>(B(),[`webKnopf(${t.quote_(e.getFieldValue("N"))})`,t.ORDER_ATOMIC]),t.com_web_slider=e=>(B(),[`webSchieberegler(${t.quote_(e.getFieldValue("N"))})`,t.ORDER_ATOMIC]),t.com_radio_init=e=>(A(),`funkEinrichten(${Number(e.getFieldValue("G"))||1});
`),t.com_radio_send=e=>(A(),`funkSenden(${R(e,"V")});
`),t.com_radio_avail=()=>(A(),["funkEmpfangen()",t.ORDER_ATOMIC]),t.com_radio_text=()=>(A(),["funkText",t.ORDER_ATOMIC]),t.com_radio_num=()=>(A(),["funkText.toFloat()",t.ORDER_ATOMIC]);const X=String.raw`// Bluetooth (BLE-UART): Nachrichten mit einer Handy-App oder dem seriellen Monitor der Werkstatt austauschen
#define BT_UART "6E400001-B5A3-F393-E0A9-E50E24DCCA9E"
#define BT_RX   "6E400002-B5A3-F393-E0A9-E50E24DCCA9E"
#define BT_TX   "6E400003-B5A3-F393-E0A9-E50E24DCCA9E"
static NimBLECharacteristic *btSenden = nullptr;
static volatile bool btNeu = false;     // fertige Nachricht liegt bereit
static volatile size_t btLaenge = 0;    // so viele Zeichen sind schon angekommen
static volatile unsigned long btZeit = 0;
static char btPuffer[201];
String btText = "";

class BtEmpfangCb : public NimBLECharacteristicCallbacks {
  void onWrite(NimBLECharacteristic *c, NimBLEConnInfo &info) override {
    if (btNeu) return; // vorige Nachricht wurde noch nicht abgeholt
    btZeit = millis();
    NimBLEAttValue v = c->getValue();
    for (size_t i = 0; i < v.size(); i++) {
      char z = (char)v.data()[i];
      if (z == '\n' || z == '\r') { if (btLaenge > 0) { btPuffer[btLaenge] = 0; btNeu = true; return; } continue; }
      if (btLaenge < 200) btPuffer[btLaenge++] = z;
    }
    btZeit = millis();
  }
};

void btEinrichten(String name)
{
  // Ist die Bluetooth-Übertragung eingeschaltet, läuft Bluetooth schon (mit deren Namen)
  bool neu = !NimBLEDevice::isInitialized();
  if (neu) NimBLEDevice::init(name.c_str());
  NimBLEServer *server = NimBLEDevice::createServer();
  server->advertiseOnDisconnect(true);
  NimBLEAdvertising *werbung = NimBLEDevice::getAdvertising();
  werbung->stop();
  NimBLEService *dienst = server->createService(BT_UART);
  dienst->createCharacteristic(BT_RX, NIMBLE_PROPERTY::WRITE | NIMBLE_PROPERTY::WRITE_NR)->setCallbacks(new BtEmpfangCb());
  btSenden = dienst->createCharacteristic(BT_TX, NIMBLE_PROPERTY::NOTIFY);
  dienst->start();
  server->start();
  if (neu) {
    werbung->addServiceUUID(BT_UART);
    werbung->enableScanResponse(true);
    werbung->setName(name.c_str());
  }
  werbung->start();
}

bool btVerbunden()
{
  return NimBLEDevice::getServer() != nullptr && NimBLEDevice::getServer()->getConnectedCount() > 0;
}

void btSende(String text)
{
  if (btSenden == nullptr || !btVerbunden()) return;
  text += "\n";
  for (unsigned int i = 0; i < text.length(); i += 20) { // in kleinen Stücken senden
    String teil = text.substring(i, i + 20);
    btSenden->setValue((const uint8_t *)teil.c_str(), teil.length());
    btSenden->notify();
    delay(5);
  }
}

bool btEmpfangen()
{
  // Nachricht ohne Zeilenende (manche Apps): nach 100 ms Pause gilt sie als fertig
  if (!btNeu && btLaenge > 0 && millis() - btZeit > 100) { btPuffer[btLaenge] = 0; btNeu = true; }
  if (!btNeu) return false;
  btText = String(btPuffer);
  btLaenge = 0;
  btNeu = false;
  return true;
}`,S=()=>{t.includes_.ble="#include <NimBLEDevice.h>",t.helpers_.ble=X};t.com_bt_init=e=>(S(),`btEinrichten(${R(e,"N")});
`),t.com_bt_send=e=>(S(),`btSende(${R(e,"V")});
`),t.com_bt_conn=()=>(S(),["btVerbunden()",t.ORDER_ATOMIC]),t.com_bt_avail=()=>(S(),["btEmpfangen()",t.ORDER_ATOMIC]),t.com_bt_text=()=>(S(),["btText",t.ORDER_ATOMIC]),t.com_bt_num=()=>(S(),["btText.toFloat()",t.ORDER_ATOMIC]);for(const e of Object.keys(t).filter(n=>/^com_/.test(n))){const n=t[e];t[e]=r=>BOARD==="esp32"&&(hasBT()||!/^com_bt_/.test(e))?n(r):r.outputConnection?["0",t.ORDER_ATOMIC]:is8266()?`// (Bluetooth gibt es beim ESP8266 nicht)
`:`// (Block nur mit dem ESP32 möglich)
`}t.controls_if=e=>{let n="",r=0;do n+=(r?" else ":"")+`if (${i(e,"IF"+r,t.ORDER_NONE,"false")}) {
${t.statementToCode(e,"DO"+r)}}`,r++;while(e.getInput("IF"+r));return e.getInput("ELSE")&&(n+=` else {
${t.statementToCode(e,"ELSE")}}`),n+`
`},t.controls_repeat_ext=e=>{const n=t.nameDB_.getDistinctName("zaehler",Blockly.VARIABLE_CATEGORY_NAME),r=i(e,"TIMES",t.ORDER_REL);return d(r)?`for (int ${n} = 0; ${n} < ${r}; ${n}++) {
${t.statementToCode(e,"DO")}}
`:`for (int ${n} = 0, ${n}_ende = ${i(e,"TIMES",t.ORDER_NONE)}; ${n} < ${n}_ende; ${n}++) {
${t.statementToCode(e,"DO")}}
`},t.controls_whileUntil=e=>{let n=i(e,"BOOL",t.ORDER_NONE,"false");return e.getFieldValue("MODE")==="UNTIL"&&(n=`!(${n})`),`while (${n}) {
${t.statementToCode(e,"DO")}}
`},t.logic_compare=e=>{const n={EQ:"==",NEQ:"!=",LT:"<",LTE:"<=",GT:">",GTE:">="}[e.getFieldValue("OP")],r=n==="=="||n==="!="?t.ORDER_EQ:t.ORDER_REL,s=valueType(e.getInputTargetBlock("A")),c=valueType(e.getInputTargetBlock("B"));if(s==="String"!=(c==="String")){const p=g=>valueType(e.getInputTargetBlock(g))==="String"?i(e,g,r):`String(${i(e,g,t.ORDER_NONE)})`;return[`${p("A")} ${n} ${p("B")}`,r]}return[`${i(e,"A",r)} ${n} ${i(e,"B",r)}`,r]},t.logic_operation=e=>{const n=e.getFieldValue("OP")==="AND",r=n?t.ORDER_AND:t.ORDER_OR;return[`${i(e,"A",r,"false")} ${n?"&&":"||"} ${i(e,"B",r,"false")}`,r]},t.logic_negate=e=>[`!${i(e,"BOOL",t.ORDER_UNARY,"true")}`,t.ORDER_UNARY],t.logic_boolean=e=>[e.getFieldValue("BOOL")==="TRUE"?"true":"false",t.ORDER_ATOMIC],t.math_number=e=>[String(e.getFieldValue("NUM")),t.ORDER_ATOMIC],t.math_arithmetic=e=>{const n={ADD:["+",t.ORDER_ADD],MINUS:["-",t.ORDER_ADD],MULTIPLY:["*",t.ORDER_MULT],DIVIDE:["/",t.ORDER_MULT],POWER:[null,t.ORDER_NONE]}[e.getFieldValue("OP")];if(!n[0])return[`pow(${i(e,"A")}, ${i(e,"B")})`,t.ORDER_ATOMIC];if(n[0]==="/"){const r=i(e,"A",n[1]);return[`${d(r)&&!r.includes(".")?r+".0":"(float)"+r} / ${i(e,"B",n[1]-.5)}`,n[1]]}return[`${i(e,"A",n[1])} ${n[0]} ${i(e,"B",n[1]-.5)}`,n[1]]},t.math_modulo=e=>[`(int)(${i(e,"DIVIDEND")}) % (int)(${i(e,"DIVISOR")})`,t.ORDER_MULT],t.math_constrain=e=>[`constrain(${i(e,"VALUE")}, ${i(e,"LOW")}, ${i(e,"HIGH")})`,t.ORDER_ATOMIC],t.math_random_int=e=>[`random(${i(e,"FROM")}, ${i(e,"TO",t.ORDER_ADD)} + 1)`,t.ORDER_ATOMIC],t.text=e=>[t.quote_(e.getFieldValue("TEXT")),t.ORDER_ATOMIC],t.variables_get=e=>[m(e.getFieldValue("VAR")),t.ORDER_ATOMIC],t.variables_set=e=>{const n=i(e,"VALUE",t.ORDER_NONE,"0"),r=t.varTypes_[e.getFieldValue("VAR")]==="String"&&valueType(e.getInputTargetBlock("VALUE"))!=="String";return`${m(e.getFieldValue("VAR"))} = ${r?`String(${n})`:n};
`},t.math_change=e=>`${m(e.getFieldValue("VAR"))} += ${i(e,"DELTA")};
`;const V=e=>t.nameDB_.getName(e.getFieldValue("NAME"),Blockly.PROCEDURE_CATEGORY_NAME);t.procedures_defnoreturn=t.procedures_defreturn=e=>{const n=V(e),r=(e.argumentVarModels_||[]).map(O=>`${t.varTypes_[O.getId()]||"int"} ${m(O.getId())}`),s=!!e.getInput("RETURN"),c=s?e.getInputTargetBlock("RETURN"):null,p=s?valueType(c):"void",g=t.statementToCode(e,"STACK"),$=s?`  return ${i(e,"RETURN",t.ORDER_NONE,"0")};
`:"";return t.functions_[n]=`${p} ${n}(${r.join(", ")})
{
${g}${$}}`,null};const P=e=>(e.arguments_||[]).map((n,r)=>i(e,"ARG"+r)).join(", ");t.procedures_callnoreturn=e=>`${V(e)}(${P(e)});
`,t.procedures_callreturn=e=>[`${V(e)}(${P(e)})`,t.ORDER_ATOMIC],t.procedures_ifreturn=e=>`if (${i(e,"CONDITION",t.ORDER_NONE,"false")}) {
  return${e.hasReturnValue_?" "+i(e,"VALUE"):""};
}
`,bordCpp(t)}();function generateArduinoCode(t){return Arduino.workspace_=t,Arduino.workspaceToCode(t)}
