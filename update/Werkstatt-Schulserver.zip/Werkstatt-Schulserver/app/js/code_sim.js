"use strict";function setupSimGenerator(){const e=Blockly.JavaScript;e.STATEMENT_PREFIX=`await api.hl(%1);
`,e.INFINITE_LOOP_TRAP=`await api.tick();
`;const i=(a,t,l,o)=>e.valueToCode(a,t,l||e.ORDER_NONE)||o||"0",d=a=>/^[A-Z]/.test(a)?a:(isNrf()?"P":"D")+a,n=(a,t)=>`'${d(a.getFieldValue(t||"PIN"))}'`,p=a=>e.nameDB_.getName(a,Blockly.VARIABLE_CATEGORY_NAME),$=a=>`[${parseInt(a.slice(1,3),16)}, ${parseInt(a.slice(3,5),16)}, ${parseInt(a.slice(5,7),16)}]`;e.ard_main=a=>`async function __setup() {
`+e.statementToCode(a,"SETUP")+`}
async function __loop() {
`+e.statementToCode(a,"LOOP")+`}
`,e.ard_setup=a=>`async function __setup() {
`+e.statementToCode(a,"DO")+`}
`,e.ard_loop=a=>`async function __loop() {
`+e.statementToCode(a,"DO")+`}
`,e.ard_wait=a=>`await api.wait((${i(a,"N")}) * ${a.getFieldValue("UNIT")==="S"?1e3:1});
`,e.ard_count=a=>{const t=p(a.getFieldValue("VAR")),l=e.nameDB_.getDistinctName("__ziel",Blockly.VARIABLE_CATEGORY_NAME),o=e.nameDB_.getDistinctName("__schritt",Blockly.VARIABLE_CATEGORY_NAME),R=e.addLoopTrap(e.statementToCode(a,"DO"),a);return`{ let ${l} = ${i(a,"TO")}; ${t} = ${i(a,"FROM")}; let ${o} = Math.abs(${i(a,"STEP",e.ORDER_NONE,"1")}) || 1; if (${t} > ${l}) ${o} = -${o};
for (; ${o} > 0 ? ${t} <= ${l} : ${t} >= ${l}; ${t} += ${o}) {
${R}} }
`},e.ard_wait_until=a=>`while (!(${i(a,"C",e.ORDER_NONE,"true")})) { await api.wait(10); }
`,e.ard_timer=a=>(e.definitions_.stoppuhr="let __stoppuhr = 0;",[`((api.millis(1) - __stoppuhr) / ${a.getFieldValue("U")==="S"?1e3:1})`,e.ORDER_ATOMIC]),e.ard_timer_reset=()=>(e.definitions_.stoppuhr="let __stoppuhr = 0;",`__stoppuhr = api.millis(1);
`),e.ard_millis=a=>[`api.millis(${a.getFieldValue("U")==="S"?1e3:1})`,e.ORDER_ATOMIC],e.ard_builtin_led=a=>`await api.builtinLed(${a.getFieldValue("V")==="HIGH"?1:0});
`,e.ard_digital_write=a=>`await api.digitalWrite(${n(a)}, ${a.getFieldValue("V")==="HIGH"?1:0});
`,e.ard_analog_write=a=>`await api.analogWrite(${n(a)}, ${i(a,"V")});
`,e.ard_servo=a=>`await api.servo(${n(a)}, ${i(a,"DEG")});
`,e.ard_tone=a=>`await api.tone(${n(a)}, ${noteFreq(a.getFieldValue("NOTE"),a.getFieldValue("ACC"),a.getFieldValue("OCT"))}, ${i(a,"DUR")});
`,e.ard_tone_freq=a=>`await api.tone(${n(a)}, ${i(a,"FREQ")}, ${i(a,"DUR")});
`,e.car_init=a=>`api.carInit([${["LA","LB","RA","RB"].map(t=>n(a,t)).join(", ")}]);
`,e.car_drive=a=>`await api.carDrive('${a.getFieldValue("DIR")}', ${i(a,"SPEED")});
`,e.car_stop=()=>`await api.car(0, 0);
`,e.car_motors=a=>`await api.car(${i(a,"L")}, ${i(a,"R")});
`,e.ard_motor=a=>`await api.motor(${n(a,"IA")}, ${n(a,"IB")}, ${a.getFieldValue("DIR")}, ${i(a,"SPEED")});
`,e.ard_stepper=a=>`await api.stepper([${[1,2,3,4].map(t=>n(a,"P"+t)).join(", ")}], ${i(a,"N")}, '${a.getFieldValue("UNIT")}', '${a.getFieldValue("DIR")}', ${i(a,"RPM",e.ORDER_NONE,"10")});
`,e.ard_dht=a=>[`(await api.dht(${n(a)}, '${a.getFieldValue("MODEL")}', '${a.getFieldValue("WHAT")}'))`,e.ORDER_ATOMIC];const _=a=>p(a.getFieldValue("L")),s=a=>JSON.stringify(a.getField("L").getText());e.list_new=a=>`${_(a)} = new Array(${Math.max(1,Math.min(100,Number(a.getFieldValue("N"))||1))}).fill(0);
`,e.list_init=a=>`${_(a)} = ${JSON.stringify(parseListNumbers(a.getFieldValue("V")))};
`,e.list_get=a=>[`api.listGet(${_(a)}, ${i(a,"I",e.ORDER_NONE,"1")}, ${s(a)})`,e.ORDER_FUNCTION_CALL],e.list_set=a=>`api.listSet(${_(a)}, ${i(a,"I",e.ORDER_NONE,"1")}, ${i(a,"V")}, ${s(a)});
`,e.list_push=a=>`api.listPush(${_(a)}, ${i(a,"V")});
`,e.list_clear=a=>`if (Array.isArray(${_(a)})) ${_(a)}.fill(0);
`,e.list_len=a=>[`${_(a)}.length`,e.ORDER_MEMBER],e.list_stat=a=>[`api.listStat(${_(a)}, '${a.getFieldValue("OP")}')`,e.ORDER_FUNCTION_CALL],e.ard_round=a=>[`Math.${{ROUND:"round",UP:"ceil",DOWN:"floor"}[a.getFieldValue("OP")]}(${i(a,"V")})`,e.ORDER_FUNCTION_CALL],e.ard_math1=a=>[`Math.${a.getFieldValue("OP")==="ABS"?"abs":"sqrt"}(${i(a,"V")})`,e.ORDER_FUNCTION_CALL],e.ard_notone=a=>`await api.noTone(${n(a)});
`,e.ard_serial=a=>`await api.serial(${i(a,"V",e.ORDER_NONE,"''")}, ${a.getFieldValue("NL")==="Y"});
`,e.ard_lcd_init=()=>`await api.lcdInit();
`,e.ard_lcd_backlight=a=>`await api.lcdBacklight(${a.getFieldValue("ON")==="1"});
`,e.ard_lcd_clear=()=>`await api.lcdClear();
`,e.ard_lcd_print=a=>`await api.lcdPrint(${i(a,"V",e.ORDER_NONE,"''")});
`,e.ard_lcd_pos=a=>`await api.lcdSetCursor(${i(a,"COL")}, ${i(a,"ROW")});
`,e.ard_join=a=>[`(api.fmt(${i(a,"A",e.ORDER_NONE,"''")}) + api.fmt(${i(a,"B",e.ORDER_NONE,"''")}))`,e.ORDER_ATOMIC],e.ard_digital_read=a=>[`(await api.digitalRead(${n(a)}))`,e.ORDER_ATOMIC],e.ard_analog_read=a=>[`(await api.analogRead('${d(a.getFieldValue("PIN"))}'))`,e.ORDER_ATOMIC],e.ard_tmp36=a=>[`(await api.tmp36('${d(a.getFieldValue("PIN"))}', '${a.getFieldValue("UNIT")}'))`,e.ORDER_ATOMIC],e.ard_ultrasonic=a=>[`(await api.ultrasonic(${n(a,"TRIG")}, ${n(a,"ECHO")}, '${a.getFieldValue("UNIT")}'))`,e.ORDER_ATOMIC],e.ard_map=a=>[`Math.trunc(((${i(a,"V")}) - (${i(a,"A")})) * ((${i(a,"D")}) - (${i(a,"C")})) / (((${i(a,"B")}) - (${i(a,"A")})) || 1) + (${i(a,"C")}))`,e.ORDER_ATOMIC],e.neo_init=a=>`await api.neoInit(${n(a)}, ${Number(a.getFieldValue("N"))||1});
`,e.neo_set=a=>`await api.neoSet(${i(a,"I")}, ${$(a.getFieldValue("C"))});
`,e.neo_set_rgb=a=>`await api.neoSet(${i(a,"I")}, [${i(a,"R")}, ${i(a,"G")}, ${i(a,"B")}]);
`,e.neo_fill=a=>`await api.neoFill(${$(a.getFieldValue("C"))});
`,e.neo_brightness=a=>`await api.neoBrightness(${i(a,"V")});
`,e.neo_clear=()=>`await api.neoFill([0, 0, 0]);
`,e.neo_hold=()=>`await api.neoHold();
`,e.neo_show=()=>`await api.neoShow();
`;const c=(a,t)=>`await api.kpInit(${t}, [${[0,1,2,3].map(l=>`'${d(a.getFieldValue("R"+l))}'`)}], [${Array.from({length:t},(l,o)=>`'${d(a.getFieldValue("C"+o))}'`)}]);
`;e.kp_init3=a=>c(a,3),e.kp_init4=a=>c(a,4),e.kp_read=()=>`await api.kpRead();
`,e.kp_key=()=>["api.kpKey()",e.ORDER_ATOMIC],e.oled_init=()=>`await api.oledInit();
`,e.oled_clear=()=>`await api.oledClear();
`,e.oled_show=()=>`await api.oledShow();
`,e.oled_cursor=a=>`await api.oledCursor(${i(a,"X")}, ${i(a,"Y")});
`,e.oled_size=a=>`await api.oledSize(${a.getFieldValue("N")});
`,e.oled_print=a=>`await api.oledPrint(${i(a,"V",e.ORDER_NONE,"''")});
`,e.oled_pixel=a=>`await api.oledPixel(${i(a,"X")}, ${i(a,"Y")}, ${a.getFieldValue("C")});
`,e.oled_line=a=>`await api.oledLine(${i(a,"X0")}, ${i(a,"Y0")}, ${i(a,"X1")}, ${i(a,"Y1")}, ${a.getFieldValue("C")});
`,e.oled_rect=a=>`await api.oledRect(${i(a,"X")}, ${i(a,"Y")}, ${i(a,"W")}, ${i(a,"H")}, ${a.getFieldValue("F")==="1"}, ${a.getFieldValue("C")});
`,e.oled_circle=a=>`await api.oledCircle(${i(a,"X")}, ${i(a,"Y")}, ${i(a,"R")}, ${a.getFieldValue("F")==="1"}, ${a.getFieldValue("C")});
`,e.oled_bitmap=a=>{const t=Bitmap.parse(a.getFieldValue("BMP"));return`await api.oledBitmap(${i(a,"X")}, ${i(a,"Y")}, ${t.w}, ${t.h}, '${t.d}', ${a.getFieldValue("C")});
`},e.init_voltmeter_i2c=a=>`await api.adsInit('${a.getFieldValue("ADDRESS")}', ${ADS_RANGE[a.getFieldValue("RANGE")]});
`,e.read_voltmeter_differential=a=>[`(await api.adsRead('${a.getFieldValue("ADDRESS")}', 'diff', ${a.getFieldValue("KANAL")}))`,e.ORDER_ATOMIC],e.read_voltmeter_channel=a=>[`(await api.adsRead('${a.getFieldValue("ADDRESS")}', 'single', ${a.getFieldValue("KANAL")}))`,e.ORDER_ATOMIC],e.calculate_pmfc_power=a=>{const t=i(a,"VOLTAGE",e.ORDER_NONE),l=Number(a.getFieldValue("RESISTOR"))||1,o=a.getFieldValue("OUTPUT_TYPE");return[o==="MA"?`((${t}) / ${l} * 1000)`:`(Math.pow(${t}, 2) / ${l} * ${o==="UW"?1e6:1e3})`,e.ORDER_ATOMIC]},e.init_ina219_i2c=a=>`await api.inaInit('${a.getFieldValue("ADDRESS")}', '${a.getFieldValue("CALIBRATION")}');
`,e.read_ina219_value=a=>[`(await api.inaRead('${a.getFieldValue("ADDRESS")}', '${a.getFieldValue("MEASURE_MODE")}'))`,e.ORDER_ATOMIC];const r=(a,t)=>i(a,t,e.ORDER_NONE,"''");e.com_usb_avail=()=>["(await api.usbAvail())",e.ORDER_ATOMIC],e.com_usb_text=()=>["api.usbText()",e.ORDER_ATOMIC],e.com_usb_num=()=>["api.usbNum()",e.ORDER_ATOMIC],e.com_wifi_connect=a=>`await api.wifiConnect(${r(a,"SSID")}, ${r(a,"PW")});
`,e.com_wifi_ap=a=>`await api.wifiAp(${r(a,"SSID")}, ${r(a,"PW")});
`,e.com_wifi_ok=()=>["api.wifiOk()",e.ORDER_ATOMIC],e.com_wifi_ip=()=>["api.wifiIp()",e.ORDER_ATOMIC],e.com_web_start=a=>`await api.webStart(${r(a,"T")});
`,e.com_web_show=a=>`await api.webShow(${JSON.stringify(a.getFieldValue("N"))}, ${r(a,"V")});
`,e.com_web_button=a=>[`(await api.webButton(${JSON.stringify(a.getFieldValue("N"))}))`,e.ORDER_ATOMIC],e.com_web_slider=a=>[`(await api.webSlider(${JSON.stringify(a.getFieldValue("N"))}))`,e.ORDER_ATOMIC],e.com_radio_init=a=>`await api.radioInit(${Number(a.getFieldValue("G"))||1});
`,e.com_radio_send=a=>`await api.radioSend(${r(a,"V")});
`,e.com_radio_avail=()=>["(await api.radioAvail())",e.ORDER_ATOMIC],e.com_radio_text=()=>["api.radioText()",e.ORDER_ATOMIC],e.com_radio_num=()=>["api.radioNum()",e.ORDER_ATOMIC],e.com_bt_init=a=>`await api.btInit(${r(a,"N")});
`,e.com_bt_send=a=>`await api.btSend(${r(a,"V")});
`,e.com_bt_conn=()=>["api.btConn()",e.ORDER_ATOMIC],e.com_bt_avail=()=>["(await api.btAvail())",e.ORDER_ATOMIC],e.com_bt_text=()=>["api.btText()",e.ORDER_ATOMIC],e.com_bt_num=()=>["api.btNum()",e.ORDER_ATOMIC];const u=a=>e.nameDB_.getName(a.getFieldValue("NAME"),Blockly.PROCEDURE_CATEGORY_NAME);e.procedures_defnoreturn=e.procedures_defreturn=function(a){const t=u(a),l=(a.argumentVarModels_||[]).map(E=>p(E.getId())),o=e.statementToCode(a,"STACK"),R=a.getInput("RETURN")?e.valueToCode(a,"RETURN",e.ORDER_NONE):"";return e.definitions_["%"+t]=`async function ${t}(${l.join(", ")}) {
${o}${R?"  return "+R+`;
`:""}}`,null};const O=a=>(a.arguments_||[]).map((t,l)=>e.valueToCode(a,"ARG"+l,e.ORDER_NONE)||"0").join(", ");e.procedures_callnoreturn=a=>`await ${u(a)}(${O(a)});
`,e.procedures_callreturn=a=>[`(await ${u(a)}(${O(a)}))`,e.ORDER_ATOMIC],e.procedures_ifreturn=a=>{let t=`if (${e.valueToCode(a,"CONDITION",e.ORDER_NONE)||"false"}) {
`;return t+=a.hasReturnValue_?`  return ${e.valueToCode(a,"VALUE",e.ORDER_NONE)||"0"};
`:`  return;
`,t+`}
`},bordSim(e)}function generateSimCode(e){let i=Blockly.JavaScript.workspaceToCode(e);const d=inferVarTypes(e),n=new Set,p=new Set;for(const $ of e.getAllVariables()){const _=Blockly.JavaScript.nameDB_.getName($.getId(),Blockly.VARIABLE_CATEGORY_NAME);$.type==="Liste"?p.add(_):d[$.getId()]==="String"&&n.add(_)}return i=i.replace(/^var (.+);$/m,($,_)=>"var "+_.split(", ").map(s=>s+(p.has(s)?" = []":n.has(s)?" = ''":" = 0")).join(", ")+";"),i+`
return { setup: typeof __setup === "function" ? __setup : null, loop: typeof __loop === "function" ? __loop : null };`}
