"use strict";const Settings={bindTeacher(){const t=document.querySelector("#setTeacher");t&&(t.onchange=()=>{try{localStorage.setItem("werkstatt.lehrkraft",t.checked?"1":"0")}catch{}})},async open(t){if(this.app=t,!t.launcher){t.dialog(`<h2>Einstellungen</h2><p>Updates und Werkzeuge gibt es nur, wenn die Werkstatt über <b>„Arduino-Werkstatt starten.exe“</b> gestartet wurde.</p><section class="set-sec">
        <h3>Aufgaben</h3>
        <label class="up-check"><input type="checkbox" id="setTeacher" ${TaskEditor.teacherMode()?"checked":""}> Lehrkraft-Modus: eigene Aufgaben erstellen, bearbeiten, importieren und löschen (unter „Datei › Aufgaben“)</label>
      </section><div class="dlg-btns"><button class="btn primary" value="ok">Schließen</button></div>`),this.bindTeacher();return}let e={};try{e=await(await fetch("api/info",{cache:"no-store"})).json()}catch{}let r=!1;try{r=localStorage.getItem("werkstatt.details")==="1"}catch{}const s=n=>n?'<span class="set-ok">eingerichtet</span>':'<span class="set-no">noch nicht eingerichtet</span>',o=e.schreibbar===!1,i=o?'disabled title="Nur im Original-Ordner mit Schreibrechten (Lehrkraft)"':"";t.dialog(`<h2>Einstellungen</h2>
      <section class="set-sec">
        <h3>Programm</h3>
        <p class="set-line">Version <b>${esc(e.version||"?")}</b> · © Ulrich Aichler, alle Rechte vorbehalten (siehe Lizenzen.txt)<span class="set-path" title="${esc(e.folder||"")}">${esc(e.folder||"")}</span></p>
        ${School.on?`<div class="set-note good">Schulversion: Deine Projekte werden auf dem Schulserver gespeichert${School.who?` (Klasse ${esc(School.who.klasse)}, Tisch ${parseInt(School.who.tisch,10)}, ${esc(School.who.vorname)})`:""}.<br><b>${esc(School.server||"")}</b></div>`:e.netz?`<div class="set-note good">Netzwerk-Version: Deine Projekte werden in deinem persönlichen Ordner gespeichert:<br><b>${esc(e.projekte||"")}</b></div>`:""}
        ${o?'<div class="set-note">Der Werkstatt-Ordner ist schreibgeschützt. Updates und das Einrichten der Werkzeuge macht die Lehrkraft im Original-Ordner.</div>':""}
        <div class="set-btns">
          <button class="btn small" type="button" id="setCheck" ${o?i:e.updateRepo?"":'disabled title="Die Update-Adresse ist noch nicht eingerichtet."'}>Nach Updates suchen</button>
          <button class="btn small" type="button" id="setZip" ${i}>Update aus ZIP-Datei …</button>
          <input type="file" id="setZipFile" accept=".zip" hidden>
        </div>
        <div class="set-note" id="setUpd">${e.updateRepo?"":"Die automatische Update-Suche wird noch eingerichtet. Updates lassen sich schon jetzt aus einer ZIP-Datei einspielen."}</div>
        <div class="set-note">Beim Update werden nur das Programm und die Startdatei ersetzt. Die Ordner „Werkzeuge“, „Projekte“ und „Aufgaben“ bleiben erhalten.</div>
      </section>
      <section class="set-sec">
        <h3>Werkzeuge zum Hochladen</h3>
        <p class="set-line">Arduino Uno: ${s(e.ready)}<br>ESP32: ${s(e.readyEsp32)}<br>ESP8266 (NodeMCU): ${s(e.readyEsp8266)}<br>Calliope mini / micro:bit: ${s(e.readyNrf5)}<br>Zwischenspeicher: ${e.cacheMB!=null?e.cacheMB+" MB":"?"}</p>
        <div class="set-btns">
          <button class="btn small" type="button" id="setTools">Werkzeuge prüfen</button>
          <button class="btn small" type="button" data-setup="uno" ${i}>Uno neu einrichten</button>
          <button class="btn small" type="button" data-setup="esp32" ${i}>ESP32 neu einrichten</button>
          <button class="btn small" type="button" data-setup="esp8266" ${i}>ESP8266 neu einrichten</button>
          <button class="btn small" type="button" data-setup="nrf5" ${i}>Calliope/micro:bit neu einrichten</button>
          ${o?"":'<button class="btn small" type="button" id="setNet" title="Alle Bibliotheken jetzt einrichten, damit die Werkstatt danach schreibgeschützt (Tauschlaufwerk) laufen kann">Alles für das Netzwerk einrichten</button>'}
          <button class="btn small" type="button" id="setCache">Zwischenspeicher leeren</button>
        </div>
        <div class="set-note">„Neu einrichten“ ergänzt fehlende Teile (Internet nötig). Den Zwischenspeicher nur leeren, wenn das Übersetzen seltsame Fehler meldet – danach dauert es einmal länger.</div>
      </section>
      <section class="set-sec">
        <h3>ESP32 komplett löschen</h3>
        <div class="up-row">
          <label>Anschluss <select id="setPort"><option value="">wird gesucht …</option></select></label>
          <button class="btn small" type="button" id="setPortRefresh" title="Anschlüsse neu suchen">↻</button>
          <button class="btn small danger" type="button" id="setErase">Komplett löschen</button>
        </div>
        <div class="set-note">Hilft, wenn der ESP32 hängt, sich ständig neu startet oder per Bluetooth nicht mehr erreichbar ist. Löscht das Programm und alle gespeicherten Daten. Danach einfach wieder ein Programm hochladen.</div>
      </section>
      <section class="set-sec">
        <h3>Hochladen</h3>
        <label class="up-check"><input type="checkbox" id="setDetails" ${r?"checked":""}> Zeitmessung beim Übersetzen anzeigen (welcher Teil wie lange dauert)</label>
      </section>
      <section class="set-sec">
        <h3>Aufgaben</h3>
        <label class="up-check"><input type="checkbox" id="setTeacher" ${TaskEditor.teacherMode()?"checked":""}> Lehrkraft-Modus: eigene Aufgaben erstellen, bearbeiten, importieren und löschen (unter „Datei › Aufgaben“)</label>
      </section>
      <div class="up-steps" id="upSteps" hidden></div>
      <div class="up-bar" id="upBar" hidden><div></div></div>
      <div class="up-msg" id="upMsg"></div>
      <details class="up-log" id="upLogBox" hidden><summary>Details anzeigen</summary><pre id="upLog"></pre></details>
      <div class="dlg-btns"><button class="btn primary" value="cancel">Schließen</button></div>`);const l=document.querySelector("#dlg"),a=n=>document.querySelector(n);l.oncancel=n=>{this.busy&&n.preventDefault()},this.bindTeacher(),Uploader.app=t,a("#setDetails").onchange=n=>{try{localStorage.setItem("werkstatt.details",n.target.checked?"1":"0")}catch{}},a("#setCheck").onclick=()=>this.checkUpdate(),a("#setZip").onclick=()=>a("#setZipFile").click(),a("#setZipFile").onchange=n=>{const u=n.target.files[0];u&&this.install(u)},a("#setTools").onclick=()=>this.run("api/tools/check"),a("#setCache").onclick=()=>this.run("api/cache/clear"),a("#setNet")&&(a("#setNet").onclick=()=>this.run("api/tools/netprep")),document.querySelectorAll("[data-setup]").forEach(n=>{n.onclick=()=>{this.busy||Uploader.showSetup(n.dataset.setup)}}),a("#setPortRefresh").onclick=()=>this.loadPorts();const c=a("#setErase");c.onclick=()=>{if(this.busy)return;const n=a("#setPort").value;if(!n){Uploader.fail("Kein Anschluss gewählt. Stecke den ESP32 direkt per USB an.");return}if(!c.dataset.sure){c.dataset.sure="1",c.textContent="Wirklich löschen?",setTimeout(()=>{delete c.dataset.sure,c.textContent="Komplett löschen"},4e3);return}delete c.dataset.sure,c.textContent="Komplett löschen",this.run("api/esp32/erase?port="+encodeURIComponent(n))},this.loadPorts()},async loadPorts(){const t=document.querySelector("#setPort");if(!t)return;let e=[];try{e=await(await fetch("api/ports",{cache:"no-store"})).json()}catch{e=[]}if(!e.length){t.innerHTML='<option value="">kein Gerät gefunden</option>';return}t.innerHTML=e.map(s=>`<option value="${esc(s.port)}">${esc(s.port)} – ${esc(s.label)}</option>`).join("");const r=e.find(s=>/esp32|cp210|ch9102|ch343/i.test(s.label))||e.find(s=>!/kein USB/.test(s.label))||e[0];t.value=r.port},async run(t,e,r){if(this.busy)return{ok:!1};this.busy=!0;const s=r||document.activeElement&&document.activeElement.closest(".set-sec");if(s){let i=s;["#upSteps","#upBar","#upMsg","#upLogBox"].forEach(a=>{const c=document.querySelector(a);c&&(i.after(c),i=c)});const l=document.querySelector("#upMsg");setTimeout(()=>s.scrollIntoView({block:"start",behavior:"smooth"}),50),l&&(l.textContent="Läuft …")}document.querySelectorAll(".set-btns button, #setErase").forEach(i=>{i.disabled=!0});const o=await Uploader.runStream(t,Object.assign({method:"POST"},e||{}),1);return this.busy=!1,document.querySelectorAll(".set-btns button, #setErase").forEach(i=>{i.disabled=!!i.title&&(i.id==="setCheck"||/Original-Ordner/.test(i.title))}),o},async checkUpdate(){const t=document.querySelector("#setUpd");t.className="set-note",t.textContent="Suche nach Updates …";let e;try{e=await(await fetch("api/update/check",{cache:"no-store"})).json()}catch{e={ok:!1,error:"Keine Verbindung zum Startprogramm."}}if(!e.ok){t.className="set-note warn",t.textContent=e.error;return}if(!e.newer){t.className="set-note good",t.textContent=`Du hast die neueste Version (${e.current}).`;return}t.className="set-note good",t.innerHTML=`Neue Version <b>${esc(e.latest)}</b> verfügbar (installiert: ${esc(e.current)}).`+(e.notes?`<div class="set-notes">${esc(e.notes).slice(0,1500)}</div>`:"")+'<div class="set-btns"><button class="btn small primary" type="button" id="setInstall">Jetzt aktualisieren</button></div>',document.querySelector("#setInstall").onclick=()=>this.install(null)},async install(t){try{await this.app.save()}catch{}if((await this.run(t?"api/update/install":"api/update/install?from=github",t?{body:t}:{},document.querySelector("#setUpd").closest(".set-sec"))).ok){document.querySelectorAll("#dlg button").forEach(s=>{s.disabled=!0}),this.busy=!0;const r=document.querySelector("#upMsg");r.textContent+=" Gleich öffnet sich ein neues Fenster. Falls sich dieses hier nicht von selbst schließt, bitte schließen.",setTimeout(()=>{try{window.close()}catch{}},4e3)}}};
