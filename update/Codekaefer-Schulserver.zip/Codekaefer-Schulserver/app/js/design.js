try{localStorage.getItem("werkstatt.design")==="dunkel"&&(document.documentElement.dataset.theme="dark")}catch{}
